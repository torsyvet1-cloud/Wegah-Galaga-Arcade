import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.galaga.arcade',
  appName: 'Galaga Arcade',
  webDir: 'dist'
};

export default config;

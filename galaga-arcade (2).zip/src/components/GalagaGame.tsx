import React, { useEffect, useRef, useState } from 'react';
import { GameState, Star, Laser, Enemy, Particle, FloatingText, HighScore, EnemyType, Obstacle, ObstacleType } from '../types';
import { SoundEngine } from '../sound';
import { Shield, Volume2, VolumeX, RotateCcw, Play, Award, Zap, ChevronLeft, ChevronRight, Gamepad2, Smartphone, Touchpad, Pause, Maximize, Minimize, QrCode, Download, Laptop, ExternalLink, Copy, Check } from 'lucide-react';

interface GalagaGameProps {
  onBackToMenu: () => void;
  onSetScore: (score: number) => void;
  highScores: HighScore[];
  onAddHighScore: (name: string, score: number) => void;
  scanlineType?: 'CLASSIC' | 'SHARP' | 'MONOCHROME' | 'OFF';
}

const CANVAS_WIDTH = 450;
const CANVAS_HEIGHT = 700;

export const SHIP_CONFIGS = {
  PHOENIX: {
    id: 'PHOENIX' as const,
    name: 'Fênix',
    subName: 'Pioneira Estelar',
    desc: 'Batedor equilibrado da Aliança Estelar, com excelente controle e disparos laser precisos.',
    speedMultiplier: 4.5,
    shootCooldown: 18,
    laserPower: 1,
    laserColor: '#3b82f6',
    laserSpeed: -9,
    laserWidth: 4,
    laserHeight: 14,
    maxLives: 3,
    color: '#3b82f6',
    borderColor: 'border-blue-500/30',
    fireType: 'SINGLE' as const,
  },
  AURORA: {
    id: 'AURORA' as const,
    name: 'Aurora',
    subName: 'Predador Roxo',
    desc: 'Planador furtivo blindado com asas reflexivas púrpuras. Alta cadência de tiro.',
    speedMultiplier: 5.0,
    shootCooldown: 15,
    laserPower: 1,
    laserColor: '#c084fc',
    laserSpeed: -10,
    laserWidth: 4,
    laserHeight: 14,
    maxLives: 3,
    color: '#c084fc',
    borderColor: 'border-purple-500/30',
    fireType: 'SINGLE' as const,
  },
  NEBULA: {
    id: 'NEBULA' as const,
    name: 'Nébula',
    subName: 'Linha de Frente',
    desc: 'Interceptor de escolta rápida com fuselagem branca e asas vermelhas de alta propulsão.',
    speedMultiplier: 4.8,
    shootCooldown: 14,
    laserPower: 1,
    laserColor: '#ef4444',
    laserSpeed: -11,
    laserWidth: 4,
    laserHeight: 14,
    maxLives: 3,
    color: '#ef4444',
    borderColor: 'border-rose-500/30',
    fireType: 'SINGLE' as const,
  },
  VANGUARD: {
    id: 'VANGUARD' as const,
    name: 'Vanguarda',
    subName: 'Defensor Esmeralda',
    desc: 'Nave de patrulha com revestimento verde-esmeralda e asas douradas aerodinâmicas.',
    speedMultiplier: 4.6,
    shootCooldown: 16,
    laserPower: 1,
    laserColor: '#22c55e',
    laserSpeed: -9.5,
    laserWidth: 4,
    laserHeight: 14,
    maxLives: 3,
    color: '#22c55e',
    borderColor: 'border-green-500/30',
    fireType: 'SINGLE' as const,
  },
  MIRAGE: {
    id: 'MIRAGE' as const,
    name: 'Miragem',
    subName: 'Hiper-Laser',
    desc: 'Equipada com propulsores experimentais e bicos coletores de antimatéria. Velocidade extrema.',
    speedMultiplier: 5.4,
    shootCooldown: 12,
    laserPower: 1,
    laserColor: '#38bdf8',
    laserSpeed: -12,
    laserWidth: 4,
    laserHeight: 14,
    maxLives: 3,
    color: '#3b82f6',
    borderColor: 'border-cyan-500/30',
    fireType: 'SINGLE' as const,
  },
  SOLARIS: {
    id: 'SOLARIS' as const,
    name: 'Solaris',
    subName: 'Disparo Solar',
    desc: 'Coleta radiação solar para disparar tiros duplos paralelos. Inicia com 4 vidas!',
    speedMultiplier: 4.2,
    shootCooldown: 20,
    laserPower: 1,
    laserColor: '#facc15',
    laserSpeed: -8.5,
    laserWidth: 4,
    laserHeight: 14,
    maxLives: 4,
    color: '#facc15',
    borderColor: 'border-yellow-500/30',
    fireType: 'DUAL' as const,
  },
  SPECTER: {
    id: 'SPECTER' as const,
    name: 'Espectro',
    subName: 'Batedor Fantasma',
    desc: 'Estrutura ultra-leve e asas azul-celeste com estabilizadores avançados para velocidade máxima.',
    speedMultiplier: 6.2,
    shootCooldown: 10,
    laserPower: 1,
    laserColor: '#38bdf8',
    laserSpeed: -14,
    laserWidth: 3.5,
    laserHeight: 14,
    maxLives: 3,
    color: '#38bdf8',
    borderColor: 'border-sky-500/30',
    fireType: 'SINGLE' as const,
  },
  MANTIS: {
    id: 'MANTIS' as const,
    name: 'Mantis',
    subName: 'Agilidade Sônica',
    desc: 'Nave biomecânica ágil que projeta disparos sônicos em rápida sucessão.',
    speedMultiplier: 5.2,
    shootCooldown: 13,
    laserPower: 1,
    laserColor: '#10b981',
    laserSpeed: -11.5,
    laserWidth: 4,
    laserHeight: 14,
    maxLives: 3,
    color: '#10b981',
    borderColor: 'border-emerald-500/30',
    fireType: 'SINGLE' as const,
  },
  ASTRA: {
    id: 'ASTRA' as const,
    name: 'Astra',
    subName: 'Canhão Cósmico',
    desc: 'Equipada com canhões oscilantes de energia. Dispara uma rajada angular com 3 lasers.',
    speedMultiplier: 4.0,
    shootCooldown: 22,
    laserPower: 1,
    laserColor: '#a855f7',
    laserSpeed: -9,
    laserWidth: 4,
    laserHeight: 14,
    maxLives: 3,
    color: '#8b5cf6',
    borderColor: 'border-violet-500/30',
    fireType: 'SPREAD' as const,
  },
  TITAN: {
    id: 'TITAN' as const,
    name: 'Titã',
    subName: 'Couraçado Pesado',
    desc: 'Blindagem pesada de titânio. Seus disparos causam o dobro de dano. Inicia com 4 vidas!',
    speedMultiplier: 3.2,
    shootCooldown: 25,
    laserPower: 2,
    laserColor: '#ea580c',
    laserSpeed: -7.5,
    laserWidth: 8,
    laserHeight: 18,
    maxLives: 4,
    color: '#ea580c',
    borderColor: 'border-orange-500/30',
    fireType: 'HEAVY' as const,
  },
};

export default function GalagaGame({ onBackToMenu, onSetScore, highScores, onAddHighScore, scanlineType = 'CLASSIC' }: GalagaGameProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Interface & HUD states
  const [gameState, setGameState] = useState<GameState>('INTRO');
  const [selectedShip, setSelectedShip] = useState<
    'PHOENIX' | 'AURORA' | 'NEBULA' | 'VANGUARD' | 'MIRAGE' | 'SOLARIS' | 'SPECTER' | 'MANTIS' | 'ASTRA' | 'TITAN'
  >('PHOENIX');
  const [score, setScore] = useState(0);
  const [level, setLevel] = useState(1);
  const [lives, setLives] = useState(3);
  const [muted, setMuted] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [forceShowControls, setForceShowControls] = useState(true); // Permite testar botões no PC e exibir sempre no smartphone
  const [controlType, setControlType] = useState<'DRAG' | 'BUTTONS'>('DRAG'); // Android optimized controls
  const [autoShoot, setAutoShoot] = useState(true);
  const [showHighScoreForm, setShowHighScoreForm] = useState(false);
  const [playerName, setPlayerName] = useState('');
  const [bestScore, setBestScore] = useState(0);
  const [startLevel, setStartLevel] = useState(1);
  const [difficulty, setDifficulty] = useState<'EASY' | 'NORMAL' | 'INSANE'>('NORMAL');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showDownloadModal, setShowDownloadModal] = useState(false);
  const [copied, setCopied] = useState(false);

  // References to keep game loop variables hot and free of React re-renders
  const stateRef = useRef<{
    gameState: GameState;
    score: number;
    level: number;
    lives: number;
    playerX: number;
    playerY: number;
    playerTargetX: number; // for smooth lerp movement
    playerWidth: number;
    playerHeight: number;
    isDualShip: boolean; // DUAL SHIP MECHANIC!
    isCaptured: boolean; // Is current ship being pulled by tractor beam?
    capturedShipX: number;
    capturedShipY: number;
    captureProgress: number; // 0 to 1
    captiveShipHeldByBossId: string | null; // Id of the boss enemy holding the target ship
    
    // Inputs
    keys: { [key: string]: boolean };
    touchX: number | null;
    touching: boolean;

    // Entity lists
    stars: Star[];
    lasers: Laser[];
    enemies: Enemy[];
    obstacles: Obstacle[];
    particles: Particle[];
    floatingTexts: FloatingText[];

    // Spawning and mechanics trackers
    introTimer: number;
    formationComplete: boolean;
    levelIntroTimer: number;
    shootCooldown: number;
    enemyShootCooldown: number;
    lastTime: number;
    vibrateIntensity: number; // Screen shake
    
    // Stats for final summary
    shotsFired: number;
    shotsHit: number;
    selectedShip: 'PHOENIX' | 'AURORA' | 'NEBULA' | 'VANGUARD' | 'MIRAGE' | 'SOLARIS' | 'SPECTER' | 'MANTIS' | 'ASTRA' | 'TITAN';
    difficulty: 'EASY' | 'NORMAL' | 'INSANE';
  }>({
    gameState: 'INTRO',
    score: 0,
    level: 1,
    lives: 3,
    playerX: CANVAS_WIDTH / 2,
    playerY: CANVAS_HEIGHT - 90,
    playerTargetX: CANVAS_WIDTH / 2,
    playerWidth: 32,
    playerHeight: 32,
    isDualShip: false,
    isCaptured: false,
    capturedShipX: 0,
    capturedShipY: 0,
    captureProgress: 0,
    captiveShipHeldByBossId: null,
    keys: {},
    touchX: null,
    touching: false,
    stars: [],
    lasers: [],
    enemies: [],
    obstacles: [],
    particles: [],
    floatingTexts: [],
    introTimer: 0,
    formationComplete: false,
    levelIntroTimer: 180, // Frames (3 seconds at 60fps)
    shootCooldown: 0,
    enemyShootCooldown: 120,
    lastTime: 0,
    vibrateIntensity: 0,
    shotsFired: 0,
    shotsHit: 0,
    selectedShip: 'PHOENIX',
    difficulty: 'NORMAL',
  });

  // Track buttons pressed for on-screen touch D-pad
  const leftPressed = useRef(false);
  const rightPressed = useRef(false);
  const shootPressed = useRef(false);

  // Run dynamic device type detection (Android/iOS usually use Touch)
  useEffect(() => {
    const checkMobile = () => {
      const isTouch = ('ontouchstart' in window) || navigator.maxTouchPoints > 0;
      setIsMobile(isTouch);
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);

    // Load personal best score
    if (highScores.length > 0) {
      setBestScore(highScores[0].score);
    }

    return () => window.removeEventListener('resize', checkMobile);
  }, [highScores]);

  // Synchronize React state to the mutable stateRef so game engine matches instantly
  useEffect(() => {
    stateRef.current.selectedShip = selectedShip;
    stateRef.current.difficulty = difficulty;
  }, [selectedShip, difficulty]);

  // Lazy initialize dynamic Starfield
  useEffect(() => {
    const stars: Star[] = [];
    const colors = ['#ffffff', '#8ea5eb', '#ffe3a0', '#ff8e8e', '#de8eff'];
    for (let i = 0; i < 70; i++) {
      stars.push({
        id: i,
        x: Math.random() * CANVAS_WIDTH,
        y: Math.random() * CANVAS_HEIGHT,
        speed: 0.8 + Math.random() * 3.5,
        size: 0.5 + Math.random() * 2,
        color: colors[Math.floor(Math.random() * colors.length)],
      });
    }
    stateRef.current.stars = stars;
  }, []);

  // Set up mute toggle
  const toggleMute = () => {
    const isMutedNow = SoundEngine.toggleMute();
    setMuted(isMutedNow);
  };

  const pauseGame = () => {
    const s = stateRef.current;
    if (s.gameState === 'PLAYING') {
      s.gameState = 'PAUSED';
      setGameState('PAUSED');
      if (typeof navigator !== 'undefined' && navigator.vibrate) navigator.vibrate(15);
    }
  };

  const resumeGame = () => {
    const s = stateRef.current;
    if (s.gameState === 'PAUSED') {
      s.gameState = 'PLAYING';
      setGameState('PLAYING');
      if (typeof navigator !== 'undefined' && navigator.vibrate) navigator.vibrate(15);
    }
  };

  // Synchronize fullscreen status with UI state
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    document.addEventListener('webkitfullscreenchange', handleFullscreenChange);
    document.addEventListener('mozfullscreenchange', handleFullscreenChange);
    document.addEventListener('MSFullscreenChange', handleFullscreenChange);

    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
      document.removeEventListener('webkitfullscreenchange', handleFullscreenChange);
      document.removeEventListener('mozfullscreenchange', handleFullscreenChange);
      document.removeEventListener('MSFullscreenChange', handleFullscreenChange);
    };
  }, []);

  const toggleFullscreen = async () => {
    try {
      const container = document.getElementById('galaga_parent_container');
      if (!container) return;

      if (!document.fullscreenElement) {
        if (container.requestFullscreen) {
          await container.requestFullscreen();
        } else if ((container as any).webkitRequestFullscreen) {
          await (container as any).webkitRequestFullscreen();
        } else if ((container as any).msRequestFullscreen) {
          await (container as any).msRequestFullscreen();
        }
      } else {
        if (document.exitFullscreen) {
          await document.exitFullscreen();
        } else if ((document as any).webkitExitFullscreen) {
          await (document as any).webkitExitFullscreen();
        } else if ((document as any).msExitFullscreen) {
          await (document as any).msExitFullscreen();
        }
      }
    } catch (err) {
      console.error('Error toggling fullscreen:', err);
    }
  };

  // Keyboard controls listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      stateRef.current.keys[e.key] = true;
      
      if (e.key === ' ' || e.key === 'ArrowUp') {
        // Prevent sliding window down when pressing Space
        e.preventDefault();
      }

      if (e.key === 'p' || e.key === 'P' || e.key === 'Escape') {
        const s = stateRef.current;
        if (s.gameState === 'PLAYING') {
          pauseGame();
        } else if (s.gameState === 'PAUSED') {
          resumeGame();
        }
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      stateRef.current.keys[e.key] = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  // Initiate a clean level
  const initLevel = (lvl: number, isResettingGame: boolean = false) => {
    const s = stateRef.current;
    s.level = lvl;
    setLevel(lvl);
    s.gameState = 'PLAYING';
    setGameState('PLAYING');
    s.levelIntroTimer = 180; // Render "LEVEL X" screen
    s.formationComplete = false;
    s.introTimer = 0;
    s.lasers = [];
    s.particles = [];
    s.floatingTexts = [];
    s.obstacles = [];
    s.isCaptured = false;
    s.captureProgress = 0;

    if (isResettingGame) {
      s.score = 0;
      setScore(0);
      s.selectedShip = selectedShip; // Synchronize with the React component state!
      s.difficulty = difficulty; // Synchronize difficulty state!
      const initialLives = SHIP_CONFIGS[selectedShip]?.maxLives || 3;
      s.lives = initialLives;
      setLives(initialLives);
      s.isDualShip = false;
      s.captiveShipHeldByBossId = null;
      s.playerX = CANVAS_WIDTH / 2;
      s.playerY = CANVAS_HEIGHT - 90;
      s.shotsFired = 0;
      s.shotsHit = 0;
    } else {
      // Retain double ship or transfer current status
      s.playerTargetX = s.playerX;
    }

    // Build the grid of enemies! (Galaga features 4 rows of enemies: Yellow, Blue, Red, Yellow Bosses)
    // We will place them initially in the list and compute bezier entry paths for them!
    const enemies: Enemy[] = [];
    
    // Boss row
    const cols = 8;
    const spacingX = 36;
    const spacingY = 32;
    const startY = 80;

    for (let row = 0; row < 4; row++) {
      let type: EnemyType = 'BLUE';
      let hp = 1;
      let scoreValue = 100;
      
      if (row === 0) {
        const isEliteWave = lvl % 5 === 0;
        if (isEliteWave) {
          type = 'BOSS_ELITE';
          hp = 4 + Math.floor(lvl / 5); // Hits required: 5 for wave 5, 6 for wave 10, etc.
          scoreValue = 800; // Premium bounty
        } else {
          type = 'BOSS';
          hp = 2; // Needs 2 shots
          scoreValue = 400; // Captures players
        }
      } else if (row === 1) {
        type = 'YELLOW';
        hp = 1;
        scoreValue = 200;
      } else if (row === 2) {
        type = 'RED';
        hp = 1;
        scoreValue = 150;
      } else if (row === 3) {
        type = 'BLUE';
        hp = 1;
        scoreValue = 100;
      }

      for (let col = 0; col < cols; col++) {
        const targetGridX = (CANVAS_WIDTH / 2) - ((cols - 1) * spacingX) / 2 + col * spacingX;
        const targetGridY = startY + row * spacingY;

        // Path generation: S-curves flying in dynamically from upper left or upper right
        const path: { x: number; y: number }[] = [];
        const flyFromLeft = col % 2 === 0;
        const originX = flyFromLeft ? -50 : CANVAS_WIDTH + 50;
        const originY = 120 + row * 40;

        // Generate bezier flight path for cinematic formation entry
        for (let t = 0; t <= 1; t += 0.02) {
          // Parametric curves looping in
          const x = originX * (1 - t) * (1 - t) + (CANVAS_WIDTH / 2 + (flyFromLeft ? -120 : 120)) * 2 * (1 - t) * t + targetGridX * t * t;
          const y = -100 * (1 - t) * (1 - t) + (CANVAS_HEIGHT / 2 - 100) * 2 * (1 - t) * t + targetGridY * t * t;
          path.push({ x, y });
        }

        enemies.push({
          id: `enemy_${row}_${col}_${Date.now()}`,
          type,
          state: 'ENTERING',
          x: path[0].x,
          y: path[0].y,
          width: type === 'BOSS_ELITE' ? 30 : 24, // Boss Elite is slightly bulkier
          height: type === 'BOSS_ELITE' ? 30 : 24,
          angle: 0,
          speed: (type === 'BOSS_ELITE' ? 1.7 : 2) + Math.random() * 1.5 + (lvl * 0.2),
          gridRow: row,
          gridCol: col,
          targetGridX,
          targetGridY,
          path,
          pathIndex: 0,
          hp,
          maxHp: hp,
          scoreValue,
          shootTimer: (type === 'BOSS_ELITE' ? 60 : 100) + Math.random() * 300,
          diveTimer: (type === 'BOSS_ELITE' ? 140 : 200) + Math.random() * 500 + (row * 100),
          animFrame: 0,
          sinOffset: Math.random() * Math.PI * 2,
        });
      }
    }

    s.enemies = enemies;
    SoundEngine.playLevelSuccess();
  };

  // Safe game loops starting on mounting
  useEffect(() => {
    initLevel(1, false);
    stateRef.current.gameState = 'INTRO';
    setGameState('INTRO');

    let animationId: number;

    const gameLoop = (timestamp: number) => {
      updateGame();
      renderGame();
      animationId = requestAnimationFrame(gameLoop);
    };

    animationId = requestAnimationFrame(gameLoop);
    return () => cancelAnimationFrame(animationId);
  }, []);

  // Update logic: Core of the Arcade physics engine
  const updateGame = () => {
    const s = stateRef.current;
    if (s.gameState !== 'PLAYING') {
      if (s.gameState === 'GAMEOVER') {
        if (s.vibrateIntensity > 0) {
          s.vibrateIntensity -= 0.35;
        }
        s.stars.forEach(star => {
          star.y += star.speed * 0.4;
          if (star.y > CANVAS_HEIGHT) {
            star.y = 0;
            star.x = Math.random() * CANVAS_WIDTH;
          }
        });
        s.particles.forEach((part) => {
          part.x += part.dx;
          part.y += part.dy;
          part.life--;
          part.alpha = part.life / part.maxLife;
          if (part.life <= 0) {
            part.dead = true;
          }
        });
        s.floatingTexts.forEach((ft) => {
          ft.y -= 0.5;
          ft.life--;
          ft.alpha = ft.life / 40;
          if (ft.life <= 0) {
            ft.dead = true;
          }
        });
        s.particles = s.particles.filter(part => !part.dead);
        s.floatingTexts = s.floatingTexts.filter(ft => !ft.dead);
      }
      return;
    }

    // Adjust ship specs based on dual status
    s.playerWidth = s.isDualShip ? 64 : 32;

    // Handle screen shake decay
    if (s.vibrateIntensity > 0) {
      s.vibrateIntensity -= 0.5;
    }

    // 1. Move stars for parallax back-drop
    s.stars.forEach(star => {
      star.y += star.speed;
      if (star.y > CANVAS_HEIGHT) {
        star.y = 0;
        star.x = Math.random() * CANVAS_WIDTH;
      }
    });

    // 2. Control level transition screens
    if (s.levelIntroTimer > 0) {
      s.levelIntroTimer--;
      // Let enemies flutter nicely while level text screens are shown
      animateEnemiesInIntro();
      return;
    }

    // 3. Movement input controls for ship
    const activeShip = s.selectedShip || 'PHOENIX';
    const speedMultiplier = SHIP_CONFIGS[activeShip]?.speedMultiplier || 4.5;
    let dx = 0;

    if (s.keys['ArrowLeft'] || s.keys['a'] || leftPressed.current) {
      dx = -speedMultiplier;
    } else if (s.keys['ArrowRight'] || s.keys['d'] || rightPressed.current) {
      dx = speedMultiplier;
    }

    // Android Drag Steering support (Smooth lerp towards target position)
    if (controlType === 'DRAG' && s.touchX !== null) {
      const lerpFactor = (SHIP_CONFIGS[activeShip]?.speedMultiplier || 4.5) >= 5.5 ? 0.35 : (SHIP_CONFIGS[activeShip]?.speedMultiplier || 4.5) <= 3.5 ? 0.15 : 0.25;
      const targetX = s.touchX;
      s.playerX += (targetX - s.playerX) * lerpFactor;
    } else {
      s.playerX += dx;
    }

    // Edge boundaries
    const halfWidth = s.playerWidth / 2;
    if (s.playerX < halfWidth + 8) s.playerX = halfWidth + 8;
    if (s.playerX > CANVAS_WIDTH - halfWidth - 8) s.playerX = CANVAS_WIDTH - halfWidth - 8;

    // 4. Captive Tractor Beam mechanics
    if (s.isCaptured) {
      s.captureProgress += 0.008;
      // Oscillate ship and pull it up to Boss ship
      s.playerY -= 2;
      s.playerX += Math.sin(s.captureProgress * Math.PI * 8) * 3;
      
      const bossEnemy = s.enemies.find(e => e.tractorBeamActive);
      if (bossEnemy) {
        // Move towards boss coordinates
        s.playerTargetX = bossEnemy.x;
      }

      if (s.playerY <= (bossEnemy ? bossEnemy.y + 36 : 100) || s.captureProgress >= 1.0) {
        // Captured successfully! Save details as captive and remove player life.
        s.isCaptured = false;
        s.isDualShip = false;
        s.playerY = CANVAS_HEIGHT - 90;
        s.playerX = CANVAS_WIDTH / 2;
        
        if (bossEnemy) {
          s.captiveShipHeldByBossId = bossEnemy.id;
          s.floatingTexts.push({
            id: `text_${Date.now()}`,
            x: bossEnemy.x,
            y: bossEnemy.y - 20,
            text: "PILOTO CAPTURADO!",
            color: '#ff4444',
            alpha: 1,
            life: 80,
          });
        }
        
        s.lives--;
        setLives(s.lives);
        SoundEngine.playShipCaptured();

        if (s.lives <= 0) {
          const activeShipType = s.selectedShip || 'PHOENIX';
          const config = SHIP_CONFIGS[activeShipType] || SHIP_CONFIGS.PHOENIX;
          createGameOverExplosion(s.playerX, s.playerY, config.color);
          SoundEngine.playExplosion();

          s.gameState = 'GAMEOVER';
          setTimeout(() => {
            setGameState('GAMEOVER');
            SoundEngine.playGameOver();
            if (s.score > 0) {
              setShowHighScoreForm(true);
              setPlayerName('');
            }
          }, 2200);
        }
      }
      return; // Skip normal firing or movement while captured
    }

    // 5. Fire lasers (Auto shoot for mobile or triggers by Space / touch button)
    if (s.shootCooldown > 0) {
      s.shootCooldown--;
    }

    const wantsToShoot = s.keys[' '] || s.keys['ArrowUp'] || shootPressed.current || (autoShoot && (controlType === 'DRAG' ? s.touching : true));
    if (wantsToShoot && s.shootCooldown === 0) {
      const activeShipType = s.selectedShip || 'PHOENIX';
      const config = SHIP_CONFIGS[activeShipType] || SHIP_CONFIGS.PHOENIX;
      s.shootCooldown = config.shootCooldown;
      SoundEngine.playLaser();

      if (s.isDualShip) {
        if (config.fireType === 'SPREAD') {
          // Dual spread: shoots 3 way from left AND right side dual ships!
          s.shotsFired += 6;
          for (let i = -1; i <= 1; i++) {
            s.lasers.push({
              id: `laser_${Date.now()}_dstL_${i}`,
              x: s.playerX - 16,
              y: s.playerY - 8,
              dx: i * 2,
              dy: config.laserSpeed,
              width: config.laserWidth,
              height: config.laserHeight,
              color: config.laserColor,
              fromPlayer: true,
              power: config.laserPower,
            });
            s.lasers.push({
              id: `laser_${Date.now()}_dstR_${i}`,
              x: s.playerX + 16,
              y: s.playerY - 8,
              dx: i * 2,
              dy: config.laserSpeed,
              width: config.laserWidth,
              height: config.laserHeight,
              color: config.laserColor,
              fromPlayer: true,
              power: config.laserPower,
            });
          }
        } else if (config.fireType === 'DUAL') {
          // Solaris style Dual + Dual = 4 parallel lasers!
          s.shotsFired += 4;
          s.lasers.push({
            id: `laser_${Date.now()}_L1`,
            x: s.playerX - 22,
            y: s.playerY - 8,
            dx: 0,
            dy: config.laserSpeed,
            width: config.laserWidth,
            height: config.laserHeight,
            color: config.laserColor,
            fromPlayer: true,
            power: config.laserPower,
          });
          s.lasers.push({
            id: `laser_${Date.now()}_L2`,
            x: s.playerX - 10,
            y: s.playerY - 8,
            dx: 0,
            dy: config.laserSpeed,
            width: config.laserWidth,
            height: config.laserHeight,
            color: config.laserColor,
            fromPlayer: true,
            power: config.laserPower,
          });
          s.lasers.push({
            id: `laser_${Date.now()}_R1`,
            x: s.playerX + 10,
            y: s.playerY - 8,
            dx: 0,
            dy: config.laserSpeed,
            width: config.laserWidth,
            height: config.laserHeight,
            color: config.laserColor,
            fromPlayer: true,
            power: config.laserPower,
          });
          s.lasers.push({
            id: `laser_${Date.now()}_R2`,
            x: s.playerX + 22,
            y: s.playerY - 8,
            dx: 0,
            dy: config.laserSpeed,
            width: config.laserWidth,
            height: config.laserHeight,
            color: config.laserColor,
            fromPlayer: true,
            power: config.laserPower,
          });
        } else {
          s.shotsFired += 2;
          // Left gun
          s.lasers.push({
            id: `laser_${Date.now()}_L`,
            x: s.playerX - 16,
            y: s.playerY - 8,
            dx: 0,
            dy: config.laserSpeed,
            width: config.laserWidth,
            height: config.laserHeight,
            color: config.laserColor,
            fromPlayer: true,
            power: config.laserPower,
          });
          // Right gun
          s.lasers.push({
            id: `laser_${Date.now()}_R`,
            x: s.playerX + 16,
            y: s.playerY - 8,
            dx: 0,
            dy: config.laserSpeed,
            width: config.laserWidth,
            height: config.laserHeight,
            color: config.laserColor,
            fromPlayer: true,
            power: config.laserPower,
          });
        }
      } else {
        if (config.fireType === 'SPREAD') {
          // triple spread shot (e.g. Astra)
          s.shotsFired += 3;
          s.lasers.push({
            id: `laser_${Date.now()}_S_L`,
            x: s.playerX,
            y: s.playerY - 14,
            dx: -2,
            dy: config.laserSpeed,
            width: config.laserWidth,
            height: config.laserHeight,
            color: config.laserColor,
            fromPlayer: true,
            power: config.laserPower,
          });
          s.lasers.push({
            id: `laser_${Date.now()}_S_C`,
            x: s.playerX,
            y: s.playerY - 14,
            dx: 0,
            dy: config.laserSpeed,
            width: config.laserWidth,
            height: config.laserHeight,
            color: config.laserColor,
            fromPlayer: true,
            power: config.laserPower,
          });
          s.lasers.push({
            id: `laser_${Date.now()}_S_R`,
            x: s.playerX,
            y: s.playerY - 14,
            dx: 2,
            dy: config.laserSpeed,
            width: config.laserWidth,
            height: config.laserHeight,
            color: config.laserColor,
            fromPlayer: true,
            power: config.laserPower,
          });
        } else if (config.fireType === 'DUAL') {
          // dual shot parallel (e.g. Solaris)
          s.shotsFired += 2;
          s.lasers.push({
            id: `laser_${Date.now()}_D_L`,
            x: s.playerX - 8,
            y: s.playerY - 14,
            dx: 0,
            dy: config.laserSpeed,
            width: config.laserWidth,
            height: config.laserHeight,
            color: config.laserColor,
            fromPlayer: true,
            power: config.laserPower,
          });
          s.lasers.push({
            id: `laser_${Date.now()}_D_R`,
            x: s.playerX + 8,
            y: s.playerY - 14,
            dx: 0,
            dy: config.laserSpeed,
            width: config.laserWidth,
            height: config.laserHeight,
            color: config.laserColor,
            fromPlayer: true,
            power: config.laserPower,
          });
        } else {
          // Single or Heavy gun (Power is handled via config.laserPower)
          s.shotsFired++;
          s.lasers.push({
            id: `laser_${Date.now()}`,
            x: s.playerX,
            y: s.playerY - 14,
            dx: 0,
            dy: config.laserSpeed,
            width: config.laserWidth,
            height: config.laserHeight,
            color: config.laserColor,
            fromPlayer: true,
            power: config.laserPower,
          });
        }
      }
    }

    // 6. Laser physics
    s.lasers.forEach((laser) => {
      laser.x += laser.dx;
      laser.y += laser.dy;

      // Remove off-camera lasers
      if (laser.y < -30 || laser.y > CANVAS_HEIGHT + 30) {
        laser.dead = true;
      }
    });

    // 7. Enemy behaviors and diving patterns
    let hasEnemiesLeft = false;
    let anyEnemyEntering = false;

    // Formation sinuous sway offset when parked in grid
    s.introTimer += 0.035;
    const formationOffsX = Math.sin(s.introTimer) * 18;

    s.enemies.forEach(enemy => {
      if (enemy.dead) return;
      hasEnemiesLeft = true;
      enemy.animFrame++;

      // Trigger animations
      if (enemy.animFrame > 60) enemy.animFrame = 0;

      if (enemy.state === 'ENTERING') {
        anyEnemyEntering = true;
        // Follow bezier initial landing route
        if (enemy.pathIndex < enemy.path.length) {
          const pt = enemy.path[enemy.pathIndex];
          enemy.x = pt.x;
          enemy.y = pt.y;
          // Calculate angle facing direction of movement
          if (enemy.pathIndex < enemy.path.length - 1) {
            const next = enemy.path[enemy.pathIndex + 1];
            enemy.angle = Math.atan2(next.y - pt.y, next.x - pt.x) + Math.PI / 2;
          }
          
          let entryStep = 1;
          if (s.difficulty === 'EASY') entryStep = 0.75;
          else if (s.difficulty === 'INSANE') entryStep = 1.35;
          enemy.pathIndex += entryStep;
        } else {
          // Finished route, nest in GRID formation
          enemy.state = 'GRID';
          enemy.angle = 0;
        }
      } else if (enemy.state === 'GRID') {
        // Nestle into grid structure smoothly with side-to-side drift
        const targetX = enemy.targetGridX + formationOffsX;
        const targetY = enemy.targetGridY;
        enemy.x += (targetX - enemy.x) * 0.1;
        enemy.y += (targetY - enemy.y) * 0.1;
        enemy.angle = 0;

        // Boss-specific or standard enemy breaks formation and DIVES down!
        if (!s.formationComplete) {
          // Can't dive until entrance show is over
        } else {
          let diveCountDown = 1;
          if (s.difficulty === 'EASY') {
            diveCountDown = 0.65; // Desce mais devagar no tempo
          } else if (s.difficulty === 'INSANE') {
            diveCountDown = 1.6; // Desce muito mais rápido no tempo, atacando constantemente!
          }
          enemy.diveTimer -= diveCountDown;
          if (enemy.diveTimer <= 0) {
            enemy.state = 'DIVING';
            enemy.diveTimer = 400 + Math.random() * 600; // Reset timer for next run
            
            // Build loop flight paths for diving attacks
            const divePath: { x: number; y: number }[] = [];
            let currentX = enemy.x;
            let currentY = enemy.y;

            if (enemy.type === 'BOSS_ELITE') {
              // Custom wide sweeping helix lateral corkscrew attack paths for Boss Elite
              const direction = enemy.gridCol % 2 === 0 ? 1 : -1;
              for (let i = 0; i < 70; i++) {
                const t = i / 70;
                const loopAngle = t * Math.PI * 6; // 3 full circular spins
                // Sweeping widely side-to-side dynamically
                const sweepX = direction * Math.sin(loopAngle) * 45 + Math.sin(t * Math.PI) * 90;
                currentX = enemy.targetGridX + sweepX;
                currentY = enemy.targetGridY + t * 470 + Math.cos(loopAngle) * 15;
                divePath.push({ x: currentX, y: currentY });
              }
            } else {
              // Simple loop formulation descending down screen
              for (let i = 0; i < 40; i++) {
                const angle = (i / 40) * Math.PI * 4;
                currentX += Math.sin(angle) * 8;
                currentY += 12 + Math.cos(angle) * 4;
                divePath.push({ x: currentX, y: currentY });
              }
            }
            enemy.path = divePath;
            enemy.pathIndex = 0;
          }
        }
      } else if (enemy.state === 'DIVING') {
        // Progress down along diving paths
        if (enemy.pathIndex < enemy.path.length) {
          const pt = enemy.path[enemy.pathIndex];
          enemy.x = pt.x;
          enemy.y = pt.y;

          // Rotate head-first
          if (enemy.pathIndex < enemy.path.length - 1) {
            const next = enemy.path[enemy.pathIndex + 1];
            enemy.angle = Math.atan2(next.y - pt.y, next.x - pt.x) + Math.PI / 2;
          }

          let diveStep = 2;
          if (s.difficulty === 'EASY') diveStep = 1.35;
          else if (s.difficulty === 'INSANE') diveStep = 2.9;
          
          if (enemy.type === 'BOSS_ELITE') {
            diveStep *= 0.95; // slightly slower but covers more horizontal ground
          }
          enemy.pathIndex += diveStep; // Move fast on raids

          // Randomly trigger lasers while diving down
          let shootProb = 0.02;
          let maxEnemyLasers = 5;
          let laserSpeed = 5 + (s.level * 0.2);

          if (s.difficulty === 'EASY') {
            shootProb = 0.01;
            maxEnemyLasers = 3;
            laserSpeed = 4 + (s.level * 0.15);
          } else if (s.difficulty === 'INSANE') {
            shootProb = 0.045;
            maxEnemyLasers = 9;
            laserSpeed = 6.5 + (s.level * 0.3);
          }

          // BOSS_ELITE is highly aggressive
          if (enemy.type === 'BOSS_ELITE') {
            shootProb *= 2.5; 
            maxEnemyLasers += 8;
          }

          if (Math.random() < shootProb && s.lasers.filter(l => !l.fromPlayer).length < maxEnemyLasers) {
            if (enemy.type === 'BOSS_ELITE') {
              // Elite unique pattern: 3-way spread fire of pink lasers!
              const spreadAngles = [-0.25, 0, 0.25];
              spreadAngles.forEach(angle => {
                s.lasers.push({
                  id: `laser_enemy_${Date.now()}_${Math.random()}`,
                  x: enemy.x,
                  y: enemy.y + 12,
                  dx: Math.sin(angle) * 3 + (s.playerX - enemy.x) * 0.015,
                  dy: laserSpeed * 0.9,
                  width: 3.5,
                  height: 12,
                  color: '#f43f5e',
                  fromPlayer: false,
                  power: 1,
                });
              });
            } else {
              s.lasers.push({
                id: `laser_enemy_${Date.now()}_${Math.random()}`,
                x: enemy.x,
                y: enemy.y + 10,
                dx: (s.playerX - enemy.x) * 0.015, // Light homing drift lasers!
                dy: laserSpeed,
                width: 3,
                height: 10,
                color: '#fbbf24',
                fromPlayer: false,
                power: 1,
              });
            }
            SoundEngine.playEnemyLaser();
          }

          // BOSS / BOSS_ELITE TRACTOR BEAM TRIGGER AT BOTTOM REGION!
          if ((enemy.type === 'BOSS' || enemy.type === 'BOSS_ELITE') && enemy.y > 220 && enemy.y < 350 && !s.isDualShip && !s.isCaptured && s.captiveShipHeldByBossId === null && Math.random() < 0.04) {
            enemy.state = 'TRACTOR_BEAM';
            enemy.tractorBeamActive = true;
            enemy.tractorBeamAlpha = 0;
            enemy.tractorBeamHeight = 0;
            enemy.speed = 1; // Settle speed down
          }

        } else {
          // Wrapped up attack run, return back from top of screen to re-join grid
          enemy.state = 'RETURNING';
          enemy.y = -50;
          enemy.x = CANVAS_WIDTH / 2;
        }
      } else if (enemy.state === 'RETURNING') {
        const targetX = enemy.targetGridX + formationOffsX;
        const targetY = enemy.targetGridY;
        
        // Relocate back downwards smoothly
        enemy.x += (targetX - enemy.x) * 0.05;
        enemy.y += (targetY - enemy.y) * 0.05;
        enemy.angle = 0;

        if (Math.abs(enemy.y - targetY) < 15) {
          enemy.state = 'GRID';
        }
      } else if (enemy.state === 'TRACTOR_BEAM') {
        // Static hover emitting tractor beams
        enemy.angle = 0;
        enemy.tractorBeamAlpha = Math.min(0.65, (enemy.tractorBeamAlpha || 0) + 0.03);
        enemy.tractorBeamHeight = Math.min(CANVAS_HEIGHT - enemy.y, (enemy.tractorBeamHeight || 0) + 12);
        
        SoundEngine.playTractorBeam();

        // Check if player enters tractor beam cone below Boss
        const beamStartX = enemy.x - 30;
        const beamEndX = enemy.x + 30;
        
        if (
          !s.isCaptured &&
          s.playerX > beamStartX &&
          s.playerX < beamEndX &&
          s.playerY > enemy.y &&
          s.playerY < enemy.y + (enemy.tractorBeamHeight || 0)
        ) {
          // Capture sequence starts! Loss of control
          s.isCaptured = true;
          s.captureProgress = 0;
        }

        // De-active beam after 150 frames
        enemy.diveTimer--;
        if (enemy.diveTimer <= 0 || s.isCaptured) {
          enemy.tractorBeamActive = false;
          enemy.state = 'DIVING';
          enemy.diveTimer = 350 + Math.random() * 400;
        }
      }
    });

    if (!anyEnemyEntering) {
      s.formationComplete = true;
    }

    // Level clear handler
    if (!hasEnemiesLeft) {
      // Transition to next level
      const nextLvl = s.level + 1;
      initLevel(nextLvl);
      return;
    }

    // 8. Collisions check (Player/lasers, Enemy/lasers, Player/Enemy)
    s.lasers.forEach((laser) => {
      if (laser.dead) return;

      if (laser.fromPlayer) {
        // Player lasers hitting enemies
        s.enemies.forEach((enemy) => {
          if (enemy.dead || laser.dead) return;

          const distance = Math.hypot(laser.x - enemy.x, laser.y - enemy.y);
          if (distance < (enemy.width / 2 + laser.width / 2 + 6)) {
            // Hit enemy!
            enemy.hp -= laser.power;
            laser.dead = true;
            s.shotsHit++;

            // Visual shield burst particle
            createLaserSparkEffect(laser.x, laser.y, '#38bdf8');

            if (enemy.hp <= 0) {
              // Destroyed enemy!
              enemy.dead = true;
              s.score += enemy.scoreValue;
              setScore(s.score);
              SoundEngine.playExplosion();
              createExplosionEffect(enemy.x, enemy.y, getEnemyColor(enemy.type), true);

              // FLOAT SCORE LABELS
              s.floatingTexts.push({
                id: `points_${Date.now()}_${Math.random()}`,
                x: enemy.x,
                y: enemy.y,
                text: `+${enemy.scoreValue}`,
                color: getEnemyColor(enemy.type),
                alpha: 1,
                life: 40,
              });

              // CRITICAL: MERGE DUAL SHIP BACK IF KILLING BOSS CAPTOR!
              if (s.captiveShipHeldByBossId === enemy.id) {
                // Return captive ship and attach side-by-side to make Dual Ship!
                s.captiveShipHeldByBossId = null;
                s.isDualShip = true;
                s.isCaptured = false;
                SoundEngine.playDualShipMerge();
                
                s.floatingTexts.push({
                  id: `points_${Date.now()}_merge`,
                  x: enemy.x,
                  y: enemy.y - 20,
                  text: "NAVE DUPLA ATIVADA!",
                  color: '#4ade80',
                  alpha: 1,
                  life: 80,
                });
              }
            } else {
              SoundEngine.playBossHit();
            }
          }
        });
      } else {
        // Enemy lasers hitting player ship
        const halfShip = s.playerWidth / 2;
        if (
          laser.x > s.playerX - halfShip &&
          laser.x < s.playerX + halfShip &&
          laser.y > s.playerY - s.playerHeight / 2 &&
          laser.y < s.playerY + s.playerHeight / 2
        ) {
          // Hit player ship!
          laser.dead = true;
          handlePlayerHit();
        }
      }
    });

    // Check direct Ship-to-Enemy collisions (Raid physical crash)
    s.enemies.forEach((enemy) => {
      if (enemy.dead) return;

      const halfShip = s.playerWidth / 2;
      const shipBox = {
        left: s.playerX - halfShip,
        right: s.playerX + halfShip,
        top: s.playerY - s.playerHeight / 2,
        bottom: s.playerY + s.playerHeight / 2,
      };

      const enemyBox = {
        left: enemy.x - enemy.width / 2,
        right: enemy.x + enemy.width / 2,
        top: enemy.y - enemy.height / 2,
        bottom: enemy.y + enemy.height / 2,
      };

      // Check intersection
      if (
        shipBox.left < enemyBox.right &&
        shipBox.right > enemyBox.left &&
        shipBox.top < enemyBox.bottom &&
        shipBox.bottom > enemyBox.top
      ) {
        // CRASH BLAST!
        enemy.dead = true;
        SoundEngine.playExplosion();
        createExplosionEffect(enemy.x, enemy.y, getEnemyColor(enemy.type), true);
        handlePlayerHit();
      }
    });

    // 9. Particles physics logic
    s.particles.forEach((part) => {
      // Apply deceleration/drag specifically to glowing sparkles to create an organic, beautiful cloud effect
      if (part.shape === 'glow-dot') {
        part.dx *= 0.94;
        part.dy *= 0.94;
        // Sparkle/flicker factor
        const flicker = Math.random() > 0.15 ? 1.0 : 0.45;
        part.alpha = (part.life / part.maxLife) * flicker;
      } else {
        part.alpha = part.life / part.maxLife;
      }

      part.x += part.dx;
      part.y += part.dy;
      part.life--;

      if (part.life <= 0) {
        part.dead = true;
      }
    });

    // Floating text decay logic
    s.floatingTexts.forEach((ft) => {
      ft.y -= 0.6;
      ft.life--;
      ft.alpha = ft.life / 40;
      if (ft.life <= 0) {
        ft.dead = true;
      }
    });

    // Spawns and updates virtual obstacles
    updateObstacles();

    // Central safe array cleanup: purge dead elements entirely
    s.lasers = s.lasers.filter(laser => !laser.dead);
    s.enemies = s.enemies.filter(enemy => !enemy.dead);
    s.obstacles = s.obstacles.filter(obs => !obs.dead);
    s.particles = s.particles.filter(part => !part.dead);
    s.floatingTexts = s.floatingTexts.filter(ft => !ft.dead);
  };

  // Logic to spawn and move retro obstacles (Meteors, Space Mines, plasma barriers)
  const updateObstacles = () => {
    const s = stateRef.current;
    
    // 1. Spawning obstacles
    if (s.gameState === 'PLAYING' && s.levelIntroTimer <= 0) {
      const frameCount = Math.floor(Date.now() / 16); // approximate frame ticks
      
      let spawnRate = 180; // frames
      let allowedTypes: ObstacleType[] = [];
      
      if (s.level === 2) {
        spawnRate = 130;
        allowedTypes = ['METEOR'];
      } else if (s.level === 3) {
        spawnRate = 140;
        allowedTypes = ['MINE'];
      } else if (s.level === 4) {
        spawnRate = 110;
        allowedTypes = ['BARRIER'];
      } else if (s.level >= 5) {
        spawnRate = 95 - Math.min(45, (s.level - 5) * 6); // gets more chaotic
        allowedTypes = ['METEOR', 'MINE', 'BARRIER'];
      }

      // Check ticks for spawn
      if (allowedTypes.length > 0 && frameCount % spawnRate === 0) {
        const type = allowedTypes[Math.floor(Math.random() * allowedTypes.length)];
        let hp = 1;
        let speedY = 1.3 + Math.random() * 1.5;
        let speedX = (Math.random() - 0.5) * 1.0;
        let size = 20 + Math.random() * 14;
        let scoreValue = 100;

        if (type === 'METEOR') {
          hp = 3;
          size = 22 + Math.random() * 14;
          speedY = 1.1 + Math.random() * 1.0;
          speedX = (Math.random() - 0.5) * 1.2;
          scoreValue = 150;
        } else if (type === 'MINE') {
          hp = 1;
          size = 14 + Math.random() * 6;
          speedY = 0.9 + Math.random() * 0.8;
          speedX = (Math.random() - 0.5) * 0.5;
          scoreValue = 200;
        } else if (type === 'BARRIER') {
          hp = 2;
          size = 28 + Math.random() * 10;
          speedY = 1.8 + Math.random() * 1.4;
          speedX = 0; // straight down
          scoreValue = 250;
        }

        s.obstacles.push({
          id: `obs_${Date.now()}_${Math.random()}`,
          type,
          x: 20 + Math.random() * (CANVAS_WIDTH - 40),
          y: -40,
          width: size,
          height: size,
          speedY,
          speedX,
          hp,
          maxHp: hp,
          rotation: Math.random() * Math.PI * 2,
          rotSpeed: (Math.random() - 0.5) * 0.04,
          scoreValue,
          size,
        });
      }
    }

    // 2. Moving and updating obstacles
    s.obstacles.forEach((obs) => {
      if (obs.dead) return;

      obs.x += obs.speedX;
      obs.y += obs.speedY;
      obs.rotation += obs.rotSpeed;

      // Wrap-around horizontal bounds or bounce off walls for screen aesthetic
      if (obs.x < obs.size / 2 || obs.x > CANVAS_WIDTH - obs.size / 2) {
        obs.speedX *= -1;
      }

      // Check collision with Player lasers
      s.lasers.forEach((laser) => {
        if (laser.dead || obs.dead) return;

        if (laser.fromPlayer) {
          const dist = Math.hypot(laser.x - obs.x, laser.y - obs.y);
          if (dist < (obs.size / 1.5 + laser.width / 2 + 3)) {
            // Laser hit obstacle!
            obs.hp -= laser.power;
            laser.dead = true;
            s.shotsHit++;
            
            // Neon hit sparkles
            createLaserSparkEffect(laser.x, laser.y, obs.type === 'MINE' ? '#f43f5e' : (obs.type === 'BARRIER' ? '#34d399' : '#e2e8f0'));

            if (obs.hp <= 0) {
              obs.dead = true;
              s.score += obs.scoreValue;
              setScore(s.score);
              SoundEngine.playExplosion();
              
              // Debris effect
              const color = obs.type === 'MINE' ? '#ef4444' : (obs.type === 'BARRIER' ? '#10b981' : '#78716c');
              createExplosionEffect(obs.x, obs.y, color);

              // Special Mine Exploding Mechanics (Spawns hazardous diagonal spikes)
              if (obs.type === 'MINE') {
                // Spawn 3 diagonal hostile sparks down
                const angles = [-Math.PI/4, 0, Math.PI/4];
                angles.forEach((ang, idx) => {
                  s.lasers.push({
                    id: `laser_mine_${Date.now()}_${idx}`,
                    x: obs.x,
                    y: obs.y,
                    dx: Math.sin(ang) * 3,
                    dy: Math.cos(ang) * 3 + 1,
                    width: 4,
                    height: 10,
                    color: '#f43f5e',
                    fromPlayer: false,
                    power: 1
                  });
                });
                
                s.floatingTexts.push({
                  id: `mine_text_${Date.now()}`,
                  x: obs.x,
                  y: obs.y - 15,
                  text: "MINA DETONADA!",
                  color: '#ef4444',
                  alpha: 1,
                  life: 40
                });
              } else {
                s.floatingTexts.push({
                  id: `obs_text_${Date.now()}`,
                  x: obs.x,
                  y: obs.y,
                  text: `+${obs.scoreValue}`,
                  color: color,
                  alpha: 1,
                  life: 40
                });
              }
            }
          }
        }
      });

      if (obs.dead) return;

      // Check if obstacle is off bottom
      if (obs.y > CANVAS_HEIGHT + 50) {
        obs.dead = true;
        return;
      }

      // Check collision with player ship
      const halfShip = s.playerWidth / 2;
      const shipBox = {
        left: s.playerX - halfShip,
        right: s.playerX + halfShip,
        top: s.playerY - s.playerHeight / 2,
        bottom: s.playerY + s.playerHeight / 2,
      };

      const obsBox = {
        left: obs.x - obs.size / 2,
        right: obs.x + obs.size / 2,
        top: obs.y - obs.size / 2,
        bottom: obs.y + obs.size / 2,
      };

      if (
        shipBox.left < obsBox.right &&
        shipBox.right > obsBox.left &&
        shipBox.top < obsBox.bottom &&
        shipBox.bottom > obsBox.top
      ) {
        // Physical crash with obstacle!
        obs.dead = true;
        SoundEngine.playExplosion();
        
        const color = obs.type === 'MINE' ? '#ef4444' : (obs.type === 'BARRIER' ? '#10b981' : '#78716c');
        createExplosionEffect(obs.x, obs.y, color);
        
        // Trigger Player Damage
        handlePlayerHit();
      }
    });
  };


  // Player ship logic when hit
  const handlePlayerHit = () => {
    const s = stateRef.current;
    s.vibrateIntensity = 8; // Screen rumble feedback

    // Spawn sparks
    createExplosionEffect(s.playerX, s.playerY, '#ef4444');

    if (s.isDualShip) {
      // Lose double status, become single ship but live!
      s.isDualShip = false;
      s.floatingTexts.push({
        id: `hint_${Date.now()}`,
        x: s.playerX,
        y: s.playerY - 20,
        text: "DANO CRÍTICO!",
        color: '#ffbe3b',
        alpha: 1,
        life: 50,
      });
      SoundEngine.playExplosion();
    } else {
      // Blow up. Lose normal single ship
      s.lives--;
      setLives(s.lives);

      if (s.lives <= 0) {
        const activeShipType = s.selectedShip || 'PHOENIX';
        const config = SHIP_CONFIGS[activeShipType] || SHIP_CONFIGS.PHOENIX;
        createGameOverExplosion(s.playerX, s.playerY, config.color);
        SoundEngine.playExplosion();

        s.gameState = 'GAMEOVER';
        setTimeout(() => {
          setGameState('GAMEOVER');
          SoundEngine.playGameOver();
          if (s.score > 0) {
            setShowHighScoreForm(true);
            setPlayerName('');
          }
        }, 2200);
      } else {
        // Respawn flash feedback
        s.playerX = CANVAS_WIDTH / 2;
        s.playerY = CANVAS_HEIGHT - 90;
        s.floatingTexts.push({
          id: `hint_${Date.now()}`,
          x: s.playerX,
          y: s.playerY - 25,
          text: "CHANCE EXTRA!",
          color: '#fbbf24',
          alpha: 1,
          life: 60,
        });
      }
    }
  };

  // Floating score and item colors helper
  const getEnemyColor = (type: EnemyType): string => {
    switch (type) {
      case 'BOSS_ELITE': return '#e11d48';
      case 'BOSS': return '#facc15';
      case 'YELLOW': return '#fb923c';
      case 'RED': return '#f87171';
      case 'BLUE': return '#60a5fa';
    }
  };

  // Spark and laser blast emission helpers
  const createLaserSparkEffect = (x: number, y: number, color: string) => {
    const s = stateRef.current;
    for (let i = 0; i < 6; i++) {
      s.particles.push({
        id: `spark_${Date.now()}_${Math.random()}`,
        x,
        y,
        dx: (Math.random() - 0.5) * 4,
        dy: (Math.random() - 0.5) * 4,
        size: 1.5 + Math.random() * 2,
        color,
        alpha: 1,
        life: 15,
        maxLife: 15,
      });
    }
  };

  const createCollateralParticleTracer = (x1: number, y1: number, x2: number, y2: number, color: string) => {
    const s = stateRef.current;
    const angle = Math.atan2(y2 - y1, x2 - x1);
    const steps = 8;
    for (let i = 0; i < steps; i++) {
      const frac = i / steps;
      const rx = x1 + (x2 - x1) * frac;
      const ry = y1 + (y2 - y1) * frac;
      // High-impact sparkling glowing tracelines passing through
      s.particles.push({
        id: `collateral_tracer_${Date.now()}_${Math.random()}`,
        x: rx,
        y: ry,
        dx: Math.cos(angle) * (1 + Math.random() * 2) + (Math.random() - 0.5) * 1.5,
        dy: Math.sin(angle) * (1 + Math.random() * 2) + (Math.random() - 0.5) * 1.5,
        size: 1.0 + Math.random() * 1.5,
        color: '#ffffff',
        alpha: 1,
        life: 15 + Math.random() * 15,
        maxLife: 30,
        shape: 'glow-dot',
      });
      s.particles.push({
        id: `collateral_tracer_tint_${Date.now()}_${Math.random()}`,
        x: rx,
        y: ry,
        dx: (Math.random() - 0.5) * 2,
        dy: (Math.random() - 0.5) * 2,
        size: 1.5 + Math.random() * 2.0,
        color,
        alpha: 0.8,
        life: 10 + Math.random() * 15,
        maxLife: 25,
      });
    }
  };

  const triggerCollateralDamage = (sourceX: number, sourceY: number, radius: number, damage: number) => {
    const s = stateRef.current;
    
    // Scan standard active enemies that are close
    const affected: { enemy: any; distance: number }[] = [];
    s.enemies.forEach(enemy => {
      if (enemy.dead) return;
      const dist = Math.hypot(enemy.x - sourceX, enemy.y - sourceY);
      if (dist <= radius) {
        affected.push({ enemy, distance: dist });
      }
    });

    // Sort to damage closest first
    affected.sort((a, b) => a.distance - b.distance);

    affected.forEach(({ enemy }) => {
      if (enemy.dead) return; // Has already been chain destroyed

      enemy.hp -= damage;
      createCollateralParticleTracer(sourceX, sourceY, enemy.x, enemy.y, getEnemyColor(enemy.type));

      // Quick visual burst tag
      s.floatingTexts.push({
        id: `coll_text_${Date.now()}_${Math.random()}`,
        x: enemy.x,
        y: enemy.y - 12,
        text: "💥 DANO COLATERAL!",
        color: '#ffbe1a',
        alpha: 1,
        life: 30,
      });

      if (enemy.hp <= 0) {
        enemy.dead = true;
        s.score += enemy.scoreValue;
        setScore(s.score);
        SoundEngine.playExplosion();

        // Chain trigger another explosion with canChain set to false to prevent infinite game-skipping feedback loops!
        createExplosionEffect(enemy.x, enemy.y, getEnemyColor(enemy.type), true, false);

        s.floatingTexts.push({
          id: `points_coll_${Date.now()}_${Math.random()}`,
          x: enemy.x,
          y: enemy.y,
          text: `+${enemy.scoreValue} (COMBO)`,
          color: '#38bdf8',
          alpha: 1,
          life: 40,
        });
      } else {
        SoundEngine.playBossHit();
      }
    });
  };

  const createExplosionEffect = (x: number, y: number, color: string, isEnemyExplosion: boolean = false, canChain: boolean = true) => {
    const s = stateRef.current;
    
    // Add juicy retro camera kick/shake for enemies blowing up
    if (isEnemyExplosion) {
      s.vibrateIntensity = Math.min(s.vibrateIntensity + 6, 14);
    }

    // 1. Standard colored debris particles (24 particles)
    for (let i = 0; i < 24; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 1.5 + Math.random() * 5;
      s.particles.push({
        id: `exp_${Date.now()}_${Math.random()}`,
        x,
        y,
        dx: Math.cos(angle) * speed,
        dy: Math.sin(angle) * speed,
        size: 2 + Math.random() * 4,
        color,
        alpha: 1,
        life: 30 + Math.random() * 20,
        maxLife: 50,
      });
    }

    // 2. High-impact bright glowing white sparkles (18 particles)
    for (let i = 0; i < 18; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 1.0 + Math.random() * 6.5; // Highly dynamic velocities
      s.particles.push({
        id: `sparkle_${Date.now()}_${Math.random()}`,
        x,
        y,
        dx: Math.cos(angle) * speed,
        dy: Math.sin(angle) * speed,
        size: 0.8 + Math.random() * 1.6, // Small, fine bright points
        color: '#ffffff',
        alpha: 1,
        life: 20 + Math.random() * 25,
        maxLife: 45,
        shape: 'glow-dot', // Specially-handled glowing particle
      });
    }

    // 3. Dynamic starburst/shock rays shooting out from the epicenter (Spokes)
    const spokeCount = isEnemyExplosion ? 14 : 6;
    for (let i = 0; i < spokeCount; i++) {
      const angle = (i / spokeCount) * Math.PI * 2 + Math.random() * 0.4;
      const speed = 3.5 + Math.random() * 4.5;
      s.particles.push({
        id: `spoke_emy_${Date.now()}_${Math.random()}`,
        x,
        y,
        dx: Math.cos(angle) * speed,
        dy: Math.sin(angle) * speed,
        size: 1.2 + Math.random() * 1.5,
        color: Math.random() > 0.4 ? color : '#ffffff',
        alpha: 1.0,
        life: 15 + Math.random() * 15,
        maxLife: 30,
        shape: 'spoke',
      });
    }

    // 4. Pixelated square remnants mimicking shattered hull armor
    const hullShardCount = isEnemyExplosion ? 10 : 4;
    for (let i = 0; i < hullShardCount; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 0.8 + Math.random() * 3.0;
      s.particles.push({
        id: `hull_${Date.now()}_${Math.random()}`,
        x,
        y,
        dx: Math.cos(angle) * speed,
        dy: Math.sin(angle) * speed,
        size: 2.5 + Math.random() * 2.5,
        color,
        alpha: 0.9,
        life: 25 + Math.random() * 20,
        maxLife: 45,
        shape: 'square',
      });
    }

    // 5. Plasma flame embers rising slightly
    const emberCount = isEnemyExplosion ? 8 : 2;
    for (let i = 0; i < emberCount; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 0.5 + Math.random() * 2.0;
      s.particles.push({
        id: `ember_${Date.now()}_${Math.random()}`,
        x,
        y,
        dx: Math.cos(angle) * speed,
        dy: Math.sin(angle) * speed - 0.5, // Drift slightly upwards
        size: 2.0 + Math.random() * 2.5,
        color: '#f97316', // Vibrant fire orange
        alpha: 1.0,
        life: 20 + Math.random() * 15,
        maxLife: 35,
        shape: 'triangle',
      });
    }

    if (isEnemyExplosion) {
      // Expanding visual radial shockwave rings
      s.particles.push({
        id: `shockwave_${Date.now()}_${Math.random()}`,
        x,
        y,
        dx: 0,
        dy: 0,
        size: 10, // expands up to (10 * 8) = 80 pixels radius
        color: '#ffffff',
        alpha: 1,
        life: 25,
        maxLife: 25,
        shape: 'ring',
      });

      s.particles.push({
        id: `shockwave_tint_${Date.now()}_${Math.random()}`,
        x,
        y,
        dx: 0,
        dy: 0,
        size: 11.5, // expands slightly more to (11.5 * 8) = 92 pixels radius
        color,
        alpha: 0.8,
        life: 20,
        maxLife: 20,
        shape: 'ring',
      });

      // Cause damage to enemies within an immediate 48px radius (only immediate neighbors) and only if chaining is enabled!
      if (canChain) {
        triggerCollateralDamage(x, y, 48, 1);
      }
    }
  };

  const createGameOverExplosion = (x: number, y: number, shipColor: string) => {
    const s = stateRef.current;
    s.vibrateIntensity = 38; // Extreme camera shaking for maximum retro drama!
    
    // Warm retro explosion colors
    const colors = [shipColor, '#ff0055', '#38bdf8', '#fb923c', '#eab308', '#ffffff'];

    // 1. Spoke vectors (instant radial blast beams)
    for (let i = 0; i < 35; i++) {
      const angle = (i / 35) * Math.PI * 2 + Math.random() * 0.2;
      const speed = 4 + Math.random() * 8;
      const color = colors[Math.floor(Math.random() * colors.length)];
      s.particles.push({
        id: `go_spoke_${Date.now()}_${Math.random()}`,
        x,
        y,
        dx: Math.cos(angle) * speed,
        dy: Math.sin(angle) * speed,
        size: 1.5 + Math.random() * 2,
        color,
        alpha: 1,
        life: 45 + Math.random() * 25,
        maxLife: 70,
        shape: 'spoke',
      });
    }

    // 2. Square pixel wreckage shards
    for (let i = 0; i < 45; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 1 + Math.random() * 4.5;
      const color = colors[Math.floor(Math.random() * colors.length)];
      s.particles.push({
        id: `go_pixel_${Date.now()}_${Math.random()}`,
        x,
        y,
        dx: Math.cos(angle) * speed,
        dy: Math.sin(angle) * speed,
        size: 3 + Math.random() * 5,
        color,
        alpha: 1,
        life: 50 + Math.random() * 40,
        maxLife: 90,
        shape: 'square',
      });
    }

    // 3. Triangle hull fragments
    for (let i = 0; i < 15; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 1.5 + Math.random() * 3;
      const color = colors[Math.floor(Math.random() * colors.length)];
      s.particles.push({
        id: `go_tri_${Date.now()}_${Math.random()}`,
        x,
        y,
        dx: Math.cos(angle) * speed,
        dy: Math.sin(angle) * speed,
        size: 4 + Math.random() * 4,
        color,
        alpha: 1,
        life: 60 + Math.random() * 30,
        maxLife: 90,
        shape: 'triangle',
      });
    }

    // 4. Multiple concentric expanding quantum plasma rings (shockwaves)
    const ringColors = ['#ffffff', shipColor, '#fb923c', '#a855f7'];
    ringColors.forEach((color, idx) => {
      s.particles.push({
        id: `go_ring_${Date.now()}_${idx}`,
        x,
        y,
        dx: 0,
        dy: 0,
        size: 12 + idx * 6, // base sizing multiplier
        color,
        alpha: 1,
        life: 40 + idx * 10,
        maxLife: 40 + idx * 10,
        shape: 'ring',
      });
    });
  };

  // Dummy action for static intro rendering before actual starting level trigger
  const animateEnemiesInIntro = () => {
    const s = stateRef.current;
    s.enemies.forEach(enemy => {
      enemy.animFrame++;
      // Flow along path if we are initiating entry curves
      if (enemy.pathIndex < enemy.path.length) {
        const pt = enemy.path[enemy.pathIndex];
        enemy.x = pt.x;
        enemy.y = pt.y;
        if (enemy.pathIndex < enemy.path.length - 1) {
          const next = enemy.path[enemy.pathIndex + 1];
          enemy.angle = Math.atan2(next.y - pt.y, next.x - pt.x) + Math.PI / 2;
        }
        enemy.pathIndex += 1;
      } else {
        // Stay parked wiggling gently
        const formationOffsX = Math.sin(s.introTimer) * 10;
        enemy.x = enemy.targetGridX + formationOffsX;
        enemy.y = enemy.targetGridY;
        enemy.angle = 0;
      }
    });

    s.stars.forEach(star => {
      star.y += star.speed * 0.4;
      if (star.y > CANVAS_HEIGHT) star.y = 0;
    });
  };

  // CANVAS RENDER SYSTEM - Crisp custom vector pixel style rendering
  const renderGame = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const s = stateRef.current;

    ctx.save();
    
    // Simulate Screen Shake Vibration
    if (s.vibrateIntensity > 0) {
      const sx = (Math.random() - 0.5) * s.vibrateIntensity;
      const sy = (Math.random() - 0.5) * s.vibrateIntensity;
      ctx.translate(sx, sy);
    }

    // A. Fill deep space black
    ctx.fillStyle = '#030712';
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // B. Draw stardust stars field
    s.stars.forEach(star => {
      ctx.fillStyle = star.color;
      ctx.fillRect(star.x, star.y, star.size, star.size);
    });

    // C. Draw Boss Tractor Beams!
    s.enemies.forEach(enemy => {
      if (enemy.tractorBeamActive) {
        const h = enemy.tractorBeamHeight || 0;
        const grad = ctx.createLinearGradient(enemy.x, enemy.y, enemy.x, enemy.y + h);
        grad.addColorStop(0, `rgba(56, 189, 248, ${0.4 * (enemy.tractorBeamAlpha || 1)})`);
        grad.addColorStop(1, 'rgba(56, 189, 248, 0)');

        ctx.fillStyle = grad;
        // Draw a neat cone projection
        ctx.beginPath();
        ctx.moveTo(enemy.x, enemy.y + 12);
        ctx.lineTo(enemy.x - 35, enemy.y + h);
        ctx.lineTo(enemy.x + 35, enemy.y + h);
        ctx.closePath();
        ctx.fill();

        // Draw tractor waves grid
        ctx.strokeStyle = `rgba(56, 189, 248, ${0.65 * (enemy.tractorBeamAlpha || 1)})`;
        ctx.lineWidth = 1.5;
        const wavesCount = Math.floor(h / 24);
        for (let i = 1; i <= wavesCount; i++) {
          const waveY = enemy.y + i * 24 + (enemy.animFrame % 24);
          if (waveY < enemy.y + h) {
            const progress = (waveY - enemy.y) / h;
            const w = 15 + progress * 50; // widening of cone wave
            ctx.beginPath();
            ctx.ellipse(enemy.x, waveY, w, 4, 0, 0, Math.PI);
            ctx.stroke();
          }
        }
      }
    });

    // D. Draw lasers
    s.lasers.forEach(laser => {
      // 1. Draw motion blur/trail afterimages (ghost layers behind the current position)
      const ghostCount = 3;
      for (let i = ghostCount; i > 0; i--) {
        const factor = i / (ghostCount + 1); // fade factor (further back is more faded)
        const ghostX = laser.x - laser.dx * i * 0.45;
        const ghostY = laser.y - laser.dy * i * 0.45;
        const ghostAlpha = 0.4 * (1 - factor);
        
        ctx.save();
        ctx.globalAlpha = ghostAlpha;
        
        // Faint trailing neon ghost
        ctx.fillStyle = laser.color;
        ctx.fillRect(ghostX - (laser.width * (1 - factor * 0.25)) / 2, ghostY, laser.width * (1 - factor * 0.25), laser.height);
        
        ctx.restore();
      }

      // 2. Draw a continuous neon speed glow line to connect the path perfectly (motion blur smear)
      const tailLength = 2.5; // Stretch length based on velocity steps
      const tailX = laser.x - laser.dx * tailLength;
      const tailY = laser.y - laser.dy * tailLength;
      
      // Create a linear gradient from the front-center of the bullet tapering to the back
      const gradient = ctx.createLinearGradient(laser.x, laser.y + laser.height / 2, tailX, tailY);
      gradient.addColorStop(0, laser.color);
      gradient.addColorStop(0.4, laser.color);
      gradient.addColorStop(1, 'transparent');

      ctx.save();
      ctx.strokeStyle = gradient;
      ctx.lineWidth = laser.width;
      ctx.lineCap = 'round';
      ctx.shadowColor = laser.color;
      ctx.shadowBlur = 6;
      ctx.beginPath();
      ctx.moveTo(laser.x, laser.y + laser.height / 2);
      ctx.lineTo(tailX, tailY);
      ctx.stroke();
      ctx.restore();

      // 3. Draw the main laser projectile core
      ctx.fillStyle = laser.color;
      ctx.fillRect(laser.x - laser.width / 2, laser.y, laser.width, laser.height);
      
      // Draw neon laser glow
      ctx.shadowColor = laser.color;
      ctx.shadowBlur = 8;
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(laser.x - laser.width / 4, laser.y + 2, laser.width / 2, laser.height - 4);
      ctx.shadowBlur = 0; // reset
    });

    // E. Draw Enemies (Retaining pure custom canvas vector models)
    s.enemies.forEach(enemy => {
      ctx.save();
      ctx.translate(enemy.x, enemy.y);
      ctx.rotate(enemy.angle);

      // Simple wing flapping offset using sin
      const flap = Math.sin(enemy.animFrame * 0.18) * 4;

      if (enemy.type === 'BOSS') {
        // Classic Galaga Boss shape
        ctx.fillStyle = enemy.hp < enemy.maxHp ? '#38bdf8' : '#eab308'; // Turns cyan/blue when damaged one time!
        // Body base
        ctx.beginPath();
        ctx.moveTo(-12, -4);
        ctx.lineTo(12, -4);
        ctx.lineTo(14, 4);
        ctx.lineTo(-14, 4);
        ctx.closePath();
        ctx.fill();

        // Blue pincers/horns on head
        ctx.fillStyle = '#3b82f6';
        ctx.beginPath();
        ctx.moveTo(-6, -12);
        ctx.lineTo(-10, -6);
        ctx.lineTo(-4, -4);
        ctx.closePath();
        ctx.fill();

        ctx.beginPath();
        ctx.moveTo(6, -12);
        ctx.lineTo(10, -6);
        ctx.lineTo(4, -4);
        ctx.closePath();
        ctx.fill();

        // Flapping beetle green/yellow side wings
        ctx.fillStyle = '#10b981';
        ctx.beginPath();
        ctx.moveTo(-12, -2);
        ctx.lineTo(-18 - flap, -8);
        ctx.lineTo(-16, 8);
        ctx.lineTo(-10, 4);
        ctx.closePath();
        ctx.fill();

        ctx.beginPath();
        ctx.moveTo(12, -2);
        ctx.lineTo(18 + flap, -8);
        ctx.lineTo(16, 8);
        ctx.lineTo(10, 4);
        ctx.closePath();
        ctx.fill();
      } else if (enemy.type === 'BOSS_ELITE') {
        // Elite red/golden emperor beetle boss
        const healthPercent = enemy.hp / enemy.maxHp;
        const wingFlap = Math.sin(enemy.animFrame * 0.25) * 6;
        
        // Base plate: Pulsing hot pink-crimson when low health, cherry crimson otherwise
        ctx.fillStyle = enemy.hp === 1 ? '#fda4af' : (enemy.hp < enemy.maxHp ? '#fb7185' : '#e11d48');
        ctx.beginPath();
        ctx.moveTo(-16, -6);
        ctx.lineTo(16, -6);
        ctx.lineTo(18, 6);
        ctx.lineTo(-18, 6);
        ctx.closePath();
        ctx.fill();

        // Core Golden Horns/Mandibles
        ctx.fillStyle = '#fbbf24';
        ctx.beginPath();
        ctx.moveTo(-8, -16);
        ctx.lineTo(-14, -8);
        ctx.lineTo(-4, -4);
        ctx.closePath();
        ctx.fill();

        ctx.beginPath();
        ctx.moveTo(8, -16);
        ctx.lineTo(14, -8);
        ctx.lineTo(4, -4);
        ctx.closePath();
        ctx.fill();

        // Outer Dark-cyan stabilizer wings
        ctx.fillStyle = '#06b6d4';
        ctx.beginPath();
        ctx.moveTo(-14, -4);
        ctx.lineTo(-24 - wingFlap, -12);
        ctx.lineTo(-20, 10);
        ctx.lineTo(-10, 6);
        ctx.closePath();
        ctx.fill();

        ctx.beginPath();
        ctx.moveTo(14, -4);
        ctx.lineTo(24 + wingFlap, -12);
        ctx.lineTo(20, 10);
        ctx.lineTo(10, 6);
        ctx.closePath();
        ctx.fill();

        // Underglow engine energy cores
        const glowRadius = 3 + Math.abs(Math.sin(enemy.animFrame * 0.12)) * 3;
        ctx.fillStyle = '#fb7185';
        ctx.beginPath();
        ctx.arc(-6, 8, glowRadius, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(6, 8, glowRadius, 0, Math.PI * 2);
        ctx.fill();
      } else if (enemy.type === 'YELLOW') {
        // Red horn moth wasp
        ctx.fillStyle = '#f97316';
        ctx.beginPath();
        ctx.moveTo(-10, -4);
        ctx.lineTo(10, -4);
        ctx.lineTo(12, 6);
        ctx.lineTo(-12, 6);
        ctx.closePath();
        ctx.fill();

        // Yellow core body
        ctx.fillStyle = '#eab308';
        ctx.fillRect(-6, -8, 12, 14);

        // Flapping thin yellow-red wings
        ctx.beginPath();
        ctx.moveTo(-10, -6);
        ctx.lineTo(-16 - flap, -12);
        ctx.lineTo(-14, 4);
        ctx.closePath();
        ctx.fill();

        ctx.beginPath();
        ctx.moveTo(10, -6);
        ctx.lineTo(16 + flap, -12);
        ctx.lineTo(14, 4);
        ctx.closePath();
        ctx.fill();
        
      } else if (enemy.type === 'RED') {
        // Red butterfly type
        ctx.fillStyle = '#ef4444';
        ctx.beginPath();
        ctx.moveTo(0, -10);
        ctx.lineTo(-8, 6);
        ctx.lineTo(8, 6);
        ctx.closePath();
        ctx.fill();

        ctx.fillStyle = '#ffffff';
        // Big round retro eyes/dots
        ctx.fillRect(-5, -4, 3, 3);
        ctx.fillRect(2, -4, 3, 3);

        // Wings
        ctx.fillStyle = '#ef3b2b';
        ctx.beginPath();
        ctx.moveTo(-8, -2);
        ctx.lineTo(-15 - flap, -6);
        ctx.lineTo(-12, 8);
        ctx.closePath();
        ctx.fill();

        ctx.beginPath();
        ctx.moveTo(8, -2);
        ctx.lineTo(15 + flap, -6);
        ctx.lineTo(12, 8);
        ctx.closePath();
        ctx.fill();
      } else {
        // BLUE standard row
        ctx.fillStyle = '#3b82f6';
        ctx.beginPath();
        ctx.moveTo(0, -9);
        ctx.lineTo(-9, 4);
        ctx.lineTo(9, 4);
        ctx.closePath();
        ctx.fill();

        // Small yellow stingers
        ctx.fillStyle = '#eab308';
        ctx.fillRect(-3, 4, 2, 4);
        ctx.fillRect(1, 4, 2, 4);

        // Side fins
        ctx.fillStyle = '#1e3a8a';
        ctx.fillRect(-12 - flap, -3, 3, 6);
        ctx.fillRect(9 + flap, -3, 3, 6);
      }

      ctx.restore();
    });

    // E2. Draw Obstacles (Asteroids, Mines, and Plasma Barriers)
    s.obstacles.forEach(obs => {
      ctx.save();
      ctx.translate(obs.x, obs.y);
      ctx.rotate(obs.rotation);

      if (obs.type === 'METEOR') {
        // Draw rocky asteroid with irregular vertices
        ctx.fillStyle = '#44403c';
        ctx.strokeStyle = '#a8a29e';
        ctx.lineWidth = 1.5;
        
        ctx.beginPath();
        const numPoints = 8;
        const radius = obs.size / 2;
        for (let j = 0; j < numPoints; j++) {
          const angle = (j / numPoints) * Math.PI * 2;
          const r = radius * (0.8 + Math.sin(angle * 3 + j) * 0.15);
          const px = Math.cos(angle) * r;
          const py = Math.sin(angle) * r;
          if (j === 0) ctx.moveTo(px, py);
          else ctx.lineTo(px, py);
        }
        ctx.closePath();
        ctx.fill();
        ctx.stroke();

        // Draw internal rock details / crater lines
        ctx.strokeStyle = '#78716c';
        ctx.beginPath();
        ctx.moveTo(-radius * 0.3, -radius * 0.3);
        ctx.lineTo(-radius * 0.1, radius * 0.1);
        ctx.moveTo(radius * 0.2, -radius * 0.1);
        ctx.lineTo(radius * 0.3, radius * 0.2);
        ctx.stroke();

      } else if (obs.type === 'MINE') {
        // Flashing cosmic mine with sharp tips
        const pulse = 1 + Math.sin(Date.now() * 0.01) * 0.15;
        const radius = (obs.size / 2) * pulse;

        // Draw outer threat outline glows
        ctx.shadowColor = '#f43f5e';
        ctx.shadowBlur = 10;
        
        ctx.strokeStyle = '#ef4444';
        ctx.fillStyle = '#020205';
        ctx.lineWidth = 2;
        
        // Spike lines protruding from mine core
        ctx.beginPath();
        for (let j = 0; j < 12; j++) {
          const angle = (j / 12) * Math.PI * 2;
          ctx.moveTo(0, 0);
          ctx.lineTo(Math.cos(angle) * (radius + 6), Math.sin(angle) * (radius + 6));
        }
        ctx.stroke();

        // Core round mine shell
        ctx.fillStyle = '#ef4444';
        ctx.beginPath();
        ctx.arc(0, 0, radius, 0, Math.PI * 2);
        ctx.fill();
        
        // Dynamic inner energy core
        ctx.fillStyle = '#fef08a';
        ctx.beginPath();
        ctx.arc(0, 0, radius * 0.5, 0, Math.PI * 2);
        ctx.fill();

        ctx.shadowBlur = 0; // reset glow

      } else if (obs.type === 'BARRIER') {
        // Plasma Grid Electronic block
        const width = obs.size * 1.5;
        const height = 12;
        
        // Neon green plasma aura
        ctx.shadowColor = '#10b981';
        ctx.shadowBlur = 12;

        ctx.fillStyle = 'rgba(16, 185, 129, 0.2)';
        ctx.strokeStyle = '#34d399';
        ctx.lineWidth = 2;

        ctx.fillRect(-width / 2, -height / 2, width, height);
        ctx.strokeRect(-width / 2, -height / 2, width, height);

        // Buzzing laser sparks lightning inside barrier
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(-width / 2 + 4, 0);
        let currentX = -width / 2 + 4;
        while (currentX < width / 2 - 4) {
          currentX += 8 + Math.random() * 8;
          const offset = (Math.random() - 0.5) * (height - 4);
          ctx.lineTo(Math.min(width / 2 - 4, currentX), offset);
        }
        ctx.stroke();

        ctx.shadowBlur = 0; // reset
      }

      ctx.restore();
    });

    // F. Draw Captive Ship if boss has it!
    s.enemies.forEach(enemy => {
      if (s.captiveShipHeldByBossId === enemy.id) {
        // Draw miniature player ship upside down above boss!
        ctx.save();
        ctx.translate(enemy.x, enemy.y - 20);
        ctx.scale(0.8, -0.8); // upside down smaller custom ship
        drawMockShip(ctx, 0, 0, false);
        ctx.restore();

        // Draw captive tractor linkage indicator
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 1;
        ctx.setLineDash([2, 4]);
        ctx.beginPath();
        ctx.moveTo(enemy.x, enemy.y);
        ctx.lineTo(enemy.x, enemy.y - 12);
        ctx.stroke();
        ctx.setLineDash([]);
      }
    });

    // G. Draw Player Ship(s)!
    if (s.isCaptured) {
      // Rotating ship pulled by tractor beam
      ctx.save();
      ctx.translate(s.playerX, s.playerY);
      ctx.rotate(s.captureProgress * Math.PI * 12); // Spin rapid!
      drawMockShip(ctx, 0, 0, false);
      ctx.restore();
    } else if (s.isDualShip) {
      // Draw DUAL SHIPS Side-by-Side!
      // Left ship
      drawMockShip(ctx, s.playerX - 16, s.playerY, true, s.levelIntroTimer > 0);
      // Right ship
      drawMockShip(ctx, s.playerX + 16, s.playerY, true, s.levelIntroTimer > 0);
    } else {
      // Normal single ship
      drawMockShip(ctx, s.playerX, s.playerY, false, s.levelIntroTimer > 0);
    }

    // H. Particles drawing
    s.particles.forEach(part => {
      ctx.save();
      ctx.fillStyle = part.color;
      ctx.strokeStyle = part.color;
      ctx.globalAlpha = part.alpha;

      if (part.shape === 'ring') {
        ctx.lineWidth = part.size * 0.4 || 2;
        ctx.beginPath();
        // Since ring size expands with life / time
        const currentRadius = (1 - part.life / part.maxLife) * (part.size * 8);
        ctx.arc(part.x, part.y, currentRadius, 0, Math.PI * 2);
        ctx.stroke();
      } else if (part.shape === 'glow-dot') {
        // High impact bright glowing white sparkles
        ctx.shadowBlur = 8;
        ctx.shadowColor = '#ffffff';
        ctx.beginPath();
        ctx.arc(part.x, part.y, part.size, 0, Math.PI * 2);
        ctx.fill();
      } else if (part.shape === 'square') {
        const sz = part.size;
        ctx.fillRect(part.x - sz / 2, part.y - sz / 2, sz, sz);
      } else if (part.shape === 'triangle') {
        ctx.beginPath();
        const sz = part.size;
        ctx.moveTo(part.x, part.y - sz);
        ctx.lineTo(part.x - sz, part.y + sz);
        ctx.lineTo(part.x + sz, part.y + sz);
        ctx.closePath();
        ctx.fill();
      } else if (part.shape === 'spoke') {
        ctx.lineWidth = part.size * 0.35 || 1.5;
        ctx.beginPath();
        const len = part.size * 3.5;
        const dxNorm = part.dx / Math.hypot(part.dx, part.dy || 0.001);
        const dyNorm = part.dy / Math.hypot(part.dx, part.dy || 0.001);
        ctx.moveTo(part.x, part.y);
        ctx.lineTo(part.x + dxNorm * len, part.y + dyNorm * len);
        ctx.stroke();
      } else {
        ctx.beginPath();
        ctx.arc(part.x, part.y, part.size, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.restore();
    });

    // I. Floating texts drawing
    s.floatingTexts.forEach(ft => {
      ctx.fillStyle = ft.color;
      ctx.globalAlpha = ft.alpha;
      ctx.font = 'bold 10px "JetBrains Mono", monospace';
      ctx.textAlign = 'center';
      ctx.fillText(ft.text, ft.x, ft.y);
      ctx.globalAlpha = 1; // reset
    });

    // J. Formation status/ready display at Level Start (INTRO PHASE)
    if (s.levelIntroTimer > 0) {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
      ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

      ctx.fillStyle = '#fbbf24';
      ctx.font = 'normal 13px "JetBrains Mono", monospace';
      ctx.textAlign = 'center';
      ctx.fillText("PREPARE SUA NAVE!", CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 - 30);

      ctx.fillStyle = '#f87171';
      ctx.font = 'bold 32px "Inter", sans-serif';
      ctx.fillText(`FASE ${s.level}`, CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 + 10);

      ctx.fillStyle = '#9ca3af';
      ctx.font = 'normal 11px "JetBrains Mono", monospace';
      ctx.fillText("O INTENSO ARCADE RETRÔ COMEÇOU", CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 + 35);
    }

    ctx.restore();
  };

  // Dedicated auxiliary helper to draw the classic shooter ship
  const drawMockShip = (
    ctx: CanvasRenderingContext2D, 
    x: number, 
    y: number, 
    isDual: boolean, 
    invulnFlash: boolean = false,
    overrideShipType?: 'PHOENIX' | 'AURORA' | 'NEBULA' | 'VANGUARD' | 'MIRAGE' | 'SOLARIS' | 'SPECTER' | 'MANTIS' | 'ASTRA' | 'TITAN'
  ) => {
    // If invulnerable, skip render dynamically
    if (invulnFlash && Math.floor(Date.now() / 150) % 2 === 0) return;

    const shipType = overrideShipType || stateRef.current?.selectedShip || 'PHOENIX';

    ctx.save();
    ctx.translate(x, y);
    if (isDual) {
      ctx.scale(0.85, 0.85); // elegant scaling so side-by-side wings do not overlap
    }

    // Standard flame thruster (Common to all, styled on engine color)
    const flameY = 14 + Math.floor(Math.random() * 6);
    const flameColor = 
      shipType === 'PHOENIX' || shipType === 'NEBULA' || shipType === 'TITAN' ? '#ef4444' :
      shipType === 'AURORA' || shipType === 'ASTRA' ? '#a855f7' :
      shipType === 'VANGUARD' || shipType === 'MANTIS' ? '#10b981' :
      shipType === 'SOLARIS' ? '#f59e0b' : '#06b6d4'; // Cyan default

    ctx.fillStyle = flameColor;
    ctx.beginPath();
    ctx.moveTo(-4, 10);
    ctx.lineTo(0, 10 + flameY);
    ctx.lineTo(4, 10);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = '#facc15'; // yellow core flame
    ctx.fillRect(-1.5, 10, 3, 3);

    if (shipType === 'PHOENIX') {
      // 1. PHOENIX (Classic Blue-White with Red nose)
      // Blue central body with long wings
      ctx.fillStyle = '#3b82f6';
      ctx.beginPath();
      ctx.moveTo(0, -18);
      ctx.lineTo(-14, 10);
      ctx.lineTo(-6, 6);
      ctx.lineTo(6, 6);
      ctx.lineTo(14, 10);
      ctx.closePath();
      ctx.fill();

      // White highlights/decals
      ctx.fillStyle = '#f3f4f6';
      ctx.beginPath();
      ctx.moveTo(-12, 8);
      ctx.lineTo(-6, 6);
      ctx.lineTo(0, -5);
      ctx.lineTo(6, 6);
      ctx.lineTo(12, 8);
      ctx.closePath();
      ctx.fill();

      // Red nose and wingtips
      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.moveTo(0, -18);
      ctx.lineTo(-3, -8);
      ctx.lineTo(3, -8);
      ctx.closePath();
      ctx.fill();
      ctx.fillRect(-14, 4, 3, 6);
      ctx.fillRect(11, 4, 3, 6);

      // Blue cockpit glass
      ctx.fillStyle = '#0ea5e9';
      ctx.beginPath();
      ctx.ellipse(0, -2, 3, 5, 0, 0, Math.PI * 2);
      ctx.fill();

    } else if (shipType === 'AURORA') {
      // 2. AURORA (Elegant Curved Purple-Gold)
      // Elegant curved purple wings
      ctx.fillStyle = '#8b5cf6';
      ctx.beginPath();
      ctx.moveTo(0, -16);
      ctx.quadraticCurveTo(-15, -4, -18, 12);
      ctx.quadraticCurveTo(-10, 8, 0, 5);
      ctx.quadraticCurveTo(10, 8, 18, 12);
      ctx.quadraticCurveTo(15, -4, 0, -16);
      ctx.closePath();
      ctx.fill();

      // Gold/Orange trim lines
      ctx.strokeStyle = '#f97316';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(-14, 8);
      ctx.lineTo(-6, 0);
      ctx.lineTo(6, 0);
      ctx.lineTo(14, 8);
      ctx.stroke();

      // Blue canopy glass
      ctx.fillStyle = '#0ea5e9';
      ctx.beginPath();
      ctx.ellipse(0, -3, 3, 6, 0, 0, Math.PI * 2);
      ctx.fill();

    } else if (shipType === 'NEBULA') {
      // 3. NEBULA (Pristine White and Red Winglets)
      // White central body
      ctx.fillStyle = '#f9fafb';
      ctx.beginPath();
      ctx.moveTo(0, -20);
      ctx.lineTo(-6, 12);
      ctx.lineTo(6, 12);
      ctx.closePath();
      ctx.fill();

      // Red side weapon pods
      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.moveTo(-6, -2);
      ctx.lineTo(-14, 12);
      ctx.lineTo(-6, 12);
      ctx.closePath();
      ctx.fill();

      ctx.beginPath();
      ctx.moveTo(6, -2);
      ctx.lineTo(14, 12);
      ctx.lineTo(6, 12);
      ctx.closePath();
      ctx.fill();

      // Cyan cockpit
      ctx.fillStyle = '#06b6d4';
      ctx.beginPath();
      ctx.ellipse(0, -4, 2.5, 6, 0, 0, Math.PI * 2);
      ctx.fill();

    } else if (shipType === 'VANGUARD') {
      // 4. VANGUARD (Leaf Green and Gold Stabilizers)
      // Green primary hull
      ctx.fillStyle = '#22c55e';
      ctx.beginPath();
      ctx.moveTo(0, -18);
      ctx.lineTo(-15, 10);
      ctx.lineTo(-5, 5);
      ctx.lineTo(5, 5);
      ctx.lineTo(15, 10);
      ctx.closePath();
      ctx.fill();

      // Yellow outer wing stabilizers
      ctx.fillStyle = '#eab308';
      ctx.fillRect(-17, 4, 3, 8);
      ctx.fillRect(14, 4, 3, 8);

      // Purple bubble canopy
      ctx.fillStyle = '#a855f7';
      ctx.beginPath();
      ctx.ellipse(0, -2, 3.5, 6, 0, 0, Math.PI * 2);
      ctx.fill();

    } else if (shipType === 'MIRAGE') {
      // 5. MIRAGE (Cobalt Deep Blue & Glowing Red core)
      // Cobalt blue wings and body
      ctx.fillStyle = '#1d4ed8';
      ctx.beginPath();
      ctx.moveTo(0, -15);
      ctx.lineTo(-16, 11);
      ctx.lineTo(-5, 4);
      ctx.lineTo(5, 4);
      ctx.lineTo(16, 11);
      ctx.closePath();
      ctx.fill();

      // Golden highlights
      ctx.fillStyle = '#facc15';
      ctx.fillRect(-16, 2, 2.5, 8);
      ctx.fillRect(13.5, 2, 2.5, 8);

      // Glowing Red central nose core
      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.moveTo(0, -20);
      ctx.lineTo(-3, -8);
      ctx.lineTo(3, -8);
      ctx.closePath();
      ctx.fill();

      // Light blue/Cyan canopy
      ctx.fillStyle = '#38bdf8';
      ctx.beginPath();
      ctx.ellipse(0, -1, 3, 5, 0, 0, Math.PI * 2);
      ctx.fill();

    } else if (shipType === 'SOLARIS') {
      // 6. SOLARIS (Bright Golden Yellow Solar Fighter)
      // Yellow wings
      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.moveTo(0, -18);
      ctx.lineTo(-15, 12);
      ctx.lineTo(-6, 6);
      ctx.lineTo(6, 6);
      ctx.lineTo(15, 12);
      ctx.closePath();
      ctx.fill();

      // Dark indigo inner fuselage
      ctx.fillStyle = '#1e1b4b';
      ctx.beginPath();
      ctx.moveTo(0, -12);
      ctx.lineTo(-5, 8);
      ctx.lineTo(5, 8);
      ctx.closePath();
      ctx.fill();

      // Purple cockpit
      ctx.fillStyle = '#ec4899';
      ctx.beginPath();
      ctx.ellipse(0, -3, 3, 5.5, 0, 0, Math.PI * 2);
      ctx.fill();

    } else if (shipType === 'SPECTER') {
      // 7. SPECTER (Stealth Aerodynamic Scout)
      // Sky blue wings
      ctx.fillStyle = '#0ea5e9';
      ctx.beginPath();
      ctx.moveTo(0, -21);
      ctx.lineTo(-16, 10);
      ctx.lineTo(-4, 4);
      ctx.lineTo(4, 4);
      ctx.lineTo(16, 10);
      ctx.closePath();
      ctx.fill();

      // Crimson highlights
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(-14, -2, 2, 12);
      ctx.fillRect(12, -2, 2, 12);

      // Blue cockpit
      ctx.fillStyle = '#0284c7';
      ctx.beginPath();
      ctx.ellipse(0, -5, 2.5, 6, 0, 0, Math.PI * 2);
      ctx.fill();

    } else if (shipType === 'MANTIS') {
      // 8. MANTIS (Bio-Mechanical Emerald and Purple)
      // Green wings
      ctx.fillStyle = '#10b981';
      ctx.beginPath();
      ctx.moveTo(0, -16);
      ctx.lineTo(-17, 11);
      ctx.lineTo(-10, 6);
      ctx.lineTo(10, 6);
      ctx.lineTo(17, 11);
      ctx.closePath();
      ctx.fill();

      // Purple inner accents
      ctx.fillStyle = '#7c3aed';
      ctx.beginPath();
      ctx.moveTo(-10, 6);
      ctx.lineTo(-3, 0);
      ctx.lineTo(3, 0);
      ctx.lineTo(10, 6);
      ctx.closePath();
      ctx.fill();

      // Golden orange canopy
      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.ellipse(0, -3, 3, 5.5, 0, 0, Math.PI * 2);
      ctx.fill();

    } else if (shipType === 'ASTRA') {
      // 9. ASTRA (Royal Purple Triple-Flame Heavy Guard)
      // Purple body and wings
      ctx.fillStyle = '#7c3aed';
      ctx.beginPath();
      ctx.moveTo(0, -18);
      ctx.lineTo(-16, 12);
      ctx.lineTo(-5, 6);
      ctx.lineTo(5, 6);
      ctx.lineTo(16, 12);
      ctx.closePath();
      ctx.fill();

      // Golden trim
      ctx.fillStyle = '#fbbf24';
      ctx.fillRect(-15, 6, 2.5, 6);
      ctx.fillRect(12.5, 6, 2.5, 6);

      // Blue dome cockpit
      ctx.fillStyle = '#38bdf8';
      ctx.beginPath();
      ctx.ellipse(0, -3, 3, 5.5, 0, 0, Math.PI * 2);
      ctx.fill();

    } else if (shipType === 'TITAN') {
      // 10. TITAN (Massive Shielded Iron Armor)
      // Sturdy white central body
      ctx.fillStyle = '#e5e7eb';
      ctx.beginPath();
      ctx.moveTo(-8, -12);
      ctx.lineTo(8, -12);
      ctx.lineTo(12, 10);
      ctx.lineTo(-12, 10);
      ctx.closePath();
      ctx.fill();

      // Heavy Red side cannons/ stabilizers
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(-16, -6, 5, 18);
      ctx.fillRect(11, -6, 5, 18);

      // Gun tip outputs
      ctx.fillStyle = '#9ca3af';
      ctx.fillRect(-15, -11, 3, 5);
      ctx.fillRect(12, -11, 3, 5);

      // Blue glass cockpit canopy
      ctx.fillStyle = '#0ea5e9';
      ctx.beginPath();
      ctx.ellipse(0, -1, 3.5, 6.5, 0, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.restore();
  };

  // High score register form execution
  const saveHighScore = (e: React.FormEvent) => {
    e.preventDefault();
    if (!playerName.trim()) return;
    onAddHighScore(playerName.trim(), score);
    setShowHighScoreForm(false);
  };

  const startNewGame = () => {
    initLevel(1, true);
  };

  // Responsive mobile touch events triggers
  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    // Initialize lazily to bypass restrictions
    SoundEngine.playLaser();
    
    if (controlType === 'DRAG') {
      const rect = e.currentTarget.getBoundingClientRect();
      const clientX = e.touches[0].clientX - rect.left;
      // Map to game coords [0, 450]
      const gameX = (clientX / rect.width) * CANVAS_WIDTH;
      stateRef.current.touchX = gameX;
      stateRef.current.touching = true;
    }
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (controlType === 'DRAG') {
      const rect = e.currentTarget.getBoundingClientRect();
      const clientX = e.touches[0].clientX - rect.left;
      const gameX = (clientX / rect.width) * CANVAS_WIDTH;
      stateRef.current.touchX = gameX;
    }
  };

  const handleTouchEnd = () => {
    stateRef.current.touching = false;
    stateRef.current.touchX = null;
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[580px] w-full px-2" id="galaga_parent_container">
      {/* 1. Header retro scores panel */}
      <div className="w-full max-w-[450px] glass-panel rounded-t-xl p-3 flex justify-between items-center text-xs font-mono select-none border-b-0 border-cyan-500/30" id="retro_hud_header">
        <div className="flex items-center gap-4 text-cyan-400">
          <div>
            <span className="text-gray-400 block uppercase text-[9px] tracking-widest font-sans font-semibold">Pontos</span>
            <span className="text-cyan-300 text-lg font-bold font-mono tracking-tight" style={{ textShadow: '0 0 6px rgba(0, 210, 255, 0.6)' }}>{score}</span>
          </div>
          <div>
            <span className="text-gray-400 block uppercase text-[9px] tracking-widest font-sans font-semibold">Fase</span>
            <span className="text-yellow-400 text-lg font-bold font-mono tracking-tight" style={{ textShadow: '0 0 6px rgba(255, 204, 0, 0.6)' }}>#{level}</span>
          </div>
        </div>

        <div className="text-center">
          <span className="text-gray-400 block uppercase text-[9px] tracking-widest font-sans font-semibold text-center h-4">Recorde</span>
          <span className="text-emerald-400 font-bold font-mono text-[15px]" style={{ textShadow: '0 0 6px rgba(52, 211, 153, 0.6)' }}>{Math.max(bestScore, score)}</span>
        </div>

        <div className="flex gap-3 items-center select-none">
          {/* Fullscreen controller toggle */}
          <button
            onClick={toggleFullscreen}
            className="p-1 px-1.5 rounded-md bg-white/[0.04] border border-cyan-500/20 text-cyan-400 hover:text-cyan-300 hover:bg-cyan-500/10 hover:border-cyan-500/40 active:scale-95 cursor-pointer flex items-center justify-center transition-all duration-150"
            id="btn_fullscreen_galaga"
            title={isFullscreen ? "Sair da Tela Cheia" : "Tela Cheia"}
          >
            {isFullscreen ? <Minimize className="w-3.5 h-3.5" /> : <Maximize className="w-3.5 h-3.5" />}
          </button>

          <div className="flex gap-1 items-center">
            {Array.from({ length: Math.max(0, lives) }).map((_, i) => (
              <div key={i} className="w-5 h-5 flex items-center justify-center text-rose-500" title={`Vida ${i + 1}`}>
                <svg viewBox="0 0 24 24" fill="currentColor" className="w-[18px] h-[18px]" style={{ filter: 'drop-shadow(0 0 4px #f43f5e)' }}>
                  <path d="M12 2L4 10h5v12h6V10h5L12 2z" />
                </svg>
              </div>
            ))}
            {lives <= 0 && <span className="text-rose-500 text-xs font-bold uppercase blink animate-pulse font-sans" style={{ textShadow: '0 0 4px rgba(244, 63, 94, 0.8)' }}>Sem Vidas</span>}
          </div>
        </div>
      </div>

      {/* 2. MAIN RETRO SCREEN CANVAS BOX */}
      <div 
        ref={containerRef}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        className="relative w-full max-w-[450px] h-[525px] overflow-hidden border-x border-b border-cyan-500/30 bg-[#020205] aspect-[450/525] rounded-b-xl flex flex-col justify-center items-center shadow-2xl shadow-cyan-500/5 touch-none select-none"
        id="galaga_canvas_container"
      >
        {/* Retro scanlines and Starfield simulation layer */}
        <div className="starfield-overlay absolute inset-0 pointer-events-none" />
        {scanlineType !== 'OFF' && (
          <>
            <div className={`absolute inset-0 pointer-events-none ${
              scanlineType === 'SHARP' 
                ? 'scanlines-sharp' 
                : scanlineType === 'MONOCHROME' 
                ? 'scanlines-monochrome' 
                : 'scanlines-classic'
            }`} />
            <div className="crt-vignette absolute inset-0 pointer-events-none" />
            <div className="crt-scan-beam absolute inset-0 pointer-events-none" />
          </>
        )}

        <canvas 
          ref={canvasRef}
          width={CANVAS_WIDTH}
          height={CANVAS_HEIGHT}
          className="w-full h-full object-cover block bg-transparent"
        />

         {/* MUTE FLOATING TOGGLE */}
        <button 
          onClick={toggleMute}
          className="absolute top-3 right-3 p-2 rounded-full border border-gray-800 bg-gray-900/80 backdrop-blur-md text-gray-400 hover:text-white transition active:scale-95 cursor-pointer z-25"
          id="toggle_audio_galaga"
          title={muted ? "Ligar som" : "Mutar som"}
        >
          {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
        </button>

        {/* PAUSE/RESUME FLOATING TOGGLE */}
        {(gameState === 'PLAYING' || gameState === 'PAUSED') && (
          <button 
            onClick={gameState === 'PAUSED' ? resumeGame : pauseGame}
            className={`absolute top-3 right-14 p-2 rounded-full border transition active:scale-95 cursor-pointer z-25 ${
              gameState === 'PAUSED' 
                ? 'border-cyan-400 bg-cyan-500/20 text-cyan-300 shadow-md shadow-cyan-500/30' 
                : 'border-gray-800 bg-gray-900/80 backdrop-blur-md text-gray-400 hover:text-white'
            }`}
            id="toggle_pause_galaga"
            title={gameState === 'PAUSED' ? "Continuar jogo" : "Pausar jogo"}
          >
            {gameState === 'PAUSED' ? <Play className="w-4 h-4 fill-current text-cyan-400" /> : <Pause className="w-4 h-4" />}
          </button>
        )}

        {/* PAUSE OVERLAY */}
        {gameState === 'PAUSED' && (
          <div className="absolute inset-0 bg-gray-950/80 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center select-none z-20 animate-fade-in" id="game_paused_overlay">
            <div className="mb-4 text-cyan-400 animate-pulse drop-shadow-[0_0_10px_rgba(0,210,255,0.6)]">
              <Pause className="w-16 h-16 stroke-[1.5] mx-auto" />
            </div>
            
            <h2 className="text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500 tracking-tight uppercase font-mono mb-2" style={{ textShadow: '0 0 15px rgba(0,210,255,0.4)' }}>
              Jogo Pausado
            </h2>
            <p className="text-gray-400 text-xs font-mono mb-8 uppercase tracking-wider">
              A frota alienígena está congelada no tempo
            </p>

            <button 
              onClick={resumeGame}
              className="w-full max-w-[200px] py-3 px-6 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-black font-extrabold text-xs tracking-wider shadow-lg shadow-cyan-500/30 hover:from-cyan-400 hover:to-blue-500 active:scale-95 cursor-pointer flex items-center justify-center gap-2 uppercase transition duration-150"
              id="btn_resume_paused_galaga"
            >
              <Play className="w-4 h-4 fill-current" /> Continuar
            </button>
          </div>
        )}

        {/* OVERLAYS FOR MENU / GAMEOVER */}
        {gameState === 'INTRO' && (
          <div className="absolute inset-0 bg-gray-950/98 flex flex-col items-center p-5 text-center select-none overflow-y-auto scrollbar-none py-6" id="game_intro_overlay">
            <div className="animate-bounce mb-1">
              <Gamepad2 className="w-12 h-12 text-amber-500" />
            </div>
            
            <h1 className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-amber-400 to-orange-500 tracking-tighter uppercase font-sans">
              GALAGA ARCADE
            </h1>
            <p className="text-yellow-500/90 text-[10px] tracking-widest font-mono font-medium uppercase mt-1 mb-3">
              ★ O clássico dos fliperamas ★
            </p>

            {/* SELETOR RETRO DE FASES E OBSTÁCULOS VIRTUAIS */}
            <div className="w-full max-w-xs space-y-2 mb-4 bg-white/[0.02] border border-cyan-500/10 p-3 rounded-xl select-none">
              <span className="text-[10px] text-cyan-400 font-mono uppercase tracking-wider flex items-center gap-1 font-bold" style={{ textShadow: '0 0 5px rgba(0, 210, 255, 0.3)' }}>
                📡 OPÇÕES DE FASE & OBSTÁCULOS
              </span>
              <div className="grid grid-cols-5 gap-1.5 pt-1">
                {[1, 2, 3, 4, 5].map((lvl) => (
                  <button
                    key={lvl}
                    onClick={() => {
                      setStartLevel(lvl);
                      if (typeof navigator !== 'undefined' && navigator.vibrate) navigator.vibrate(12);
                    }}
                    className={`p-2 rounded-lg text-xs font-bold font-mono transition active:scale-95 cursor-pointer border flex flex-col items-center justify-center ${
                      startLevel === lvl 
                        ? 'bg-cyan-500 border-cyan-400 text-black shadow-md shadow-cyan-500/20 font-extrabold' 
                        : 'bg-white/[0.04] border-white/10 text-gray-400 hover:text-white hover:bg-white/[0.08]'
                    }`}
                  >
                    <span>F{lvl}</span>
                  </button>
                ))}
              </div>
              
              {/* Descríção dinâmica das fases selecionadas */}
              <div className="text-left font-mono text-[9.5px] p-2 rounded-lg bg-black/[0.3] border border-white/5 leading-relaxed">
                {startLevel === 1 && (
                  <p className="text-gray-400">
                    🌌 <strong className="text-cyan-400">FASE 1 (Treino)</strong>: Espaço calmo. Lide apenas com os caças e drones alienígenas.
                  </p>
                )}
                {startLevel === 2 && (
                  <p className="text-gray-400">
                    🪨 <strong className="text-amber-400">FASE 2 (Asteroides)</strong>: Chuva de meteoros destrutíveis (3 HP) descendo em várias diagonais.
                  </p>
                )}
                {startLevel === 3 && (
                  <p className="text-gray-400">
                    💥 <strong className="text-rose-400">FASE 3 (Minas)</strong>: Minas espaciais eletrostáticas. Ao explodirem, disparam lasers perigosos!
                  </p>
                )}
                {startLevel === 4 && (
                  <p className="text-gray-400">
                    ⚡ <strong className="text-emerald-400">FASE 4 (Plasma)</strong>: Grandes grades de plasma vertical (2 HP) bloqueando seu caminho.
                  </p>
                )}
                {startLevel === 5 && (
                  <p className="text-gray-400">
                    🌀 <strong className="text-purple-400">FASE 5+ (Caos)</strong>: Chuvas intensas, minas e barras elétricas juntas com inimigos!
                  </p>
                )}
              </div>
            </div>

            {/* SELETOR DE DIFICULDADE */}
            <div className="w-full max-w-xs space-y-2 mb-4 bg-white/[0.02] border border-purple-500/10 p-3 rounded-xl select-none text-left">
              <span className="text-[10px] text-purple-400 font-mono uppercase tracking-wider flex items-center gap-1 font-bold" style={{ textShadow: '0 0 5px rgba(168, 85, 247, 0.3)' }}>
                ⚔️ SELETOR DE DIFICULDADE
              </span>
              <div className="grid grid-cols-3 gap-1.5 pt-1">
                {(['EASY', 'NORMAL', 'INSANE'] as const).map((diff) => {
                  const label = diff === 'EASY' ? 'Fácil' : diff === 'NORMAL' ? 'Normal' : 'Insano';
                  const activeClass = 
                    diff === 'EASY' 
                      ? 'bg-emerald-500 border-emerald-400 text-black shadow-md shadow-emerald-500/20' 
                      : diff === 'NORMAL' 
                        ? 'bg-cyan-500 border-cyan-400 text-black shadow-md shadow-cyan-500/20' 
                        : 'bg-rose-600 border-rose-500 text-white shadow-md shadow-rose-600/20';
                  const isSelected = difficulty === diff;
                  return (
                    <button
                      key={diff}
                      onClick={() => {
                        setDifficulty(diff);
                        if (typeof navigator !== 'undefined' && navigator.vibrate) navigator.vibrate(12);
                      }}
                      className={`py-2 px-1 rounded-lg text-xs font-bold font-mono transition active:scale-95 cursor-pointer border flex flex-col items-center justify-center ${
                        isSelected 
                          ? `${activeClass} font-extrabold` 
                          : 'bg-white/[0.04] border-white/10 text-gray-400 hover:text-white hover:bg-white/[0.08]'
                      }`}
                    >
                      <span>{label}</span>
                    </button>
                  );
                })}
              </div>
              <div className="text-left font-mono text-[9px] p-2 rounded-lg bg-black/[0.3] border border-white/5 leading-relaxed">
                {difficulty === 'EASY' && (
                  <p className="text-gray-400 animate-fade-in">
                    🟢 <strong className="text-emerald-400">FÁCIL</strong>: Inimigos lentos ao atacar, menor cadência e poucos lasers na tela. Ideal para novatos!
                  </p>
                )}
                {difficulty === 'NORMAL' && (
                  <p className="text-gray-400 animate-fade-in">
                    🔵 <strong className="text-cyan-400">NORMAL</strong>: A experiência clássica original balanceada e desafiadora dos arcades.
                  </p>
                )}
                {difficulty === 'INSANE' && (
                  <p className="text-gray-400 animate-fade-in">
                    🔴 <strong className="text-rose-400">INSANO</strong>: Inimigos ultra velozes, chuva ininterrupta de tiros e velocidade absurda!
                  </p>
                )}
              </div>
            </div>

            {/* SELETOR DE NAVE DE COMBATE */}
            <div className="w-full max-w-xs space-y-2 mb-4 bg-white/[0.02] border border-amber-500/20 p-3 rounded-xl select-none text-left shadow-lg shadow-amber-500/5">
              <span className="text-[10px] text-amber-400 font-mono uppercase tracking-wider flex items-center gap-1 font-bold" style={{ textShadow: '0 0 6px rgba(245, 158, 11, 0.4)' }}>
                🚀 ESCOLHA SUA NAVE DE COMBATE
              </span>
              <div className="grid grid-cols-5 gap-1 pt-1">
                {(Object.keys(SHIP_CONFIGS) as Array<keyof typeof SHIP_CONFIGS>).map((shipKey) => {
                  const conf = SHIP_CONFIGS[shipKey];
                  const isSelected = selectedShip === shipKey;
                  return (
                    <button
                      key={shipKey}
                      onClick={() => {
                        setSelectedShip(shipKey);
                        SoundEngine.playBossHit(); // Satisfying beep feedback
                        if (typeof navigator !== 'undefined' && navigator.vibrate) navigator.vibrate(12);
                      }}
                      className={`relative p-1 rounded-lg text-[9px] font-bold font-mono transition-all duration-200 active:scale-95 cursor-pointer border flex flex-col items-center justify-center gap-1.5 min-h-[62px] ${
                        isSelected 
                          ? 'bg-black/80 text-white font-extrabold scale-102 font-sans' 
                          : 'bg-white/[0.02] border-white/5 text-gray-400 hover:text-white hover:bg-white/[0.06] hover:border-white/15'
                      }`}
                      style={
                        isSelected 
                          ? { 
                              borderColor: conf.color, 
                              boxShadow: `0 0 14px ${conf.color}90, inset 0 0 8px ${conf.color}30` 
                            } 
                          : {}
                      }
                    >
                      {/* Selected glowing dot marker */}
                      {isSelected && (
                        <span className="absolute top-1 right-1 w-1.5 h-1.5 rounded-full bg-white animate-ping" style={{ backgroundColor: conf.color }} />
                      )}
                      
                      <svg className="w-6 h-6 pointer-events-none transition-transform duration-200 group-hover:scale-110" viewBox="-20 -20 40 40">
                        {shipKey === 'PHOENIX' && (
                          <>
                            <path d="M 0,-18 L -14,10 L -6,6 L 6,6 L 14,10 Z" fill="#3b82f6" />
                            <path d="M 0,-18 L -3,-8 L 3,-8 Z" fill="#ef4444" />
                            <ellipse cx="0" cy="-2" rx="4" ry="6" fill="#0ea5e9" />
                          </>
                        )}
                        {shipKey === 'AURORA' && (
                          <>
                            <path d="M 0,-16 Q -15,-4 -18,12 Q -10,8 0,5 Q 10,8 18,12 Q 15,-4 0,-16 Z" fill="#8b5cf6" />
                            <path d="M -14,8 L -6,0 L 6,0 L 14,8" stroke="#f97316" strokeWidth="1.5" fill="none" />
                            <ellipse cx="0" cy="-3" rx="3" ry="6" fill="#0ea5e9" />
                          </>
                        )}
                        {shipKey === 'NEBULA' && (
                          <>
                            <path d="M 0,-20 L -6,12 L 6,12 Z" fill="#f9fafb" />
                            <path d="M -6,-2 L -14,12 L -6,12 Z" fill="#ef4444" />
                            <path d="M 6,-2 L 14,12 L 6,12 Z" fill="#ef4444" />
                            <ellipse cx="0" cy="-4" rx="2.5" ry="6" fill="#06b6d4" />
                          </>
                        )}
                        {shipKey === 'VANGUARD' && (
                          <>
                            <path d="M 0,-18 L -15,10 L -5,5 L 5,5 L 15,10 Z" fill="#22c55e" />
                            <rect x="-17" y="4" width="3" height="8" fill="#eab308" />
                            <rect x="14" y="4" width="3" height="8" fill="#eab308" />
                            <ellipse cx="0" cy="-2" rx="3.5" ry="6" fill="#a855f7" />
                          </>
                        )}
                        {shipKey === 'MIRAGE' && (
                          <>
                            <path d="M 0,-15 L -16,11 L -5,4 L 5,4 L 16,11 Z" fill="#1d4ed8" />
                            <rect x="-16" y="2" width="2.5" height="8" fill="#facc15" />
                            <rect x="13.5" y="2" width="2.5" height="8" fill="#facc15" />
                            <path d="M 0,-20 L -3,-8 L 3,-8 Z" fill="#ef4444" />
                            <ellipse cx="0" cy="-1" rx="3" ry="5" fill="#38bdf8" />
                          </>
                        )}
                        {shipKey === 'SOLARIS' && (
                          <>
                            <path d="M 0,-18 L -15,12 L -6,6 L 6,6 L 15,12 Z" fill="#f59e0b" />
                            <path d="M 0,-12 L -5,8 L 5,8 Z" fill="#1e1b4b" />
                            <ellipse cx="0" cy="-3" rx="3" ry="5.5" fill="#ec4899" />
                          </>
                        )}
                        {shipKey === 'SPECTER' && (
                          <>
                            <path d="M 0,-21 L -16,10 L -4,4 L 4,4 L 16,10 Z" fill="#0ea5e9" />
                            <rect x="-14" y="-2" width="2" height="12" fill="#ef4444" />
                            <rect x="12" y="-2" width="2" height="12" fill="#ef4444" />
                            <ellipse cx="0" cy="-5" rx="2.5" ry="6" fill="#0284c7" />
                          </>
                        )}
                        {shipKey === 'MANTIS' && (
                          <>
                            <path d="M 0,-16 L -17,11 L -10,6 L 10,6 L 17,11 Z" fill="#10b981" />
                            <path d="M -10,6 L -3,0 L 3,0 L 10,6 Z" fill="#7c3aed" />
                            <ellipse cx="0" cy="-3" rx="3" ry="5.5" fill="#f59e0b" />
                          </>
                        )}
                        {shipKey === 'ASTRA' && (
                          <>
                            <path d="M 0,-18 L -16,12 L -5,6 L 5,6 L 16,12 Z" fill="#7c3aed" />
                            <rect x="-15" y="6" width="2.5" height="6" fill="#fbbf24" />
                            <rect x="12.5" y="6" width="2.5" height="6" fill="#fbbf24" />
                            <ellipse cx="0" cy="-3" rx="3" ry="5.5" fill="#38bdf8" />
                          </>
                        )}
                        {shipKey === 'TITAN' && (
                          <>
                            <path d="M -8,-12 L 8,-12 L 12,10 L -12,10 Z" fill="#e5e7eb" />
                            <rect x="-16" y="-6" width="5" height="18" fill="#ef4444" />
                            <rect x="11" y="-6" width="5" height="18" fill="#ef4444" />
                            <rect x="-15" y="-11" width="3" height="5" fill="#9ca3af" />
                            <rect x="12" y="-11" width="3" height="5" fill="#9ca3af" />
                            <ellipse cx="0" cy="-1" rx="3.5" ry="6.5" fill="#0ea5e9" />
                          </>
                        )}
                      </svg>
                      <span className="truncate max-w-full text-[8px] uppercase tracking-tighter" style={{ fontSize: '7px', color: isSelected ? '#ffffff' : '#9ca3af' }}>{conf.name}</span>
                    </button>
                  );
                })}
              </div>

              <div className="font-mono text-[9px] p-2.5 rounded-lg bg-black/[0.3] border border-white/5 space-y-2">
                <div className="flex justify-between font-bold border-b border-white/5 pb-1">
                  <span style={{ color: SHIP_CONFIGS[selectedShip].color }}>⭐ {SHIP_CONFIGS[selectedShip].name}</span>
                  <span className="opacity-70 text-[8px] uppercase">{SHIP_CONFIGS[selectedShip].subName}</span>
                </div>
                <p className="text-gray-400 leading-normal text-[8.5px]">
                  {SHIP_CONFIGS[selectedShip].desc}
                </p>
                <div className="grid grid-cols-2 gap-y-2 pt-1.5 text-[8.5px] text-gray-500">
                  <div className="space-y-0.5">
                    <div>VELOCIDADE: <strong className="text-gray-300">{SHIP_CONFIGS[selectedShip].speedMultiplier.toFixed(1)}</strong></div>
                    <div className="text-[7.5px] text-cyan-400/80 font-mono">
                      {"█".repeat(Math.min(10, Math.round(SHIP_CONFIGS[selectedShip].speedMultiplier * 1.5)))}
                      {"░".repeat(Math.max(0, 10 - Math.round(SHIP_CONFIGS[selectedShip].speedMultiplier * 1.5)))}
                    </div>
                  </div>
                  <div className="space-y-0.5">
                    <div>CADÊNCIA: <strong className="text-gray-300">{SHIP_CONFIGS[selectedShip].shootCooldown <= 12 ? 'ULTRA' : SHIP_CONFIGS[selectedShip].shootCooldown <= 15 ? 'RÁPIDA' : SHIP_CONFIGS[selectedShip].shootCooldown <= 19 ? 'MÉDIA' : 'LENTA'}</strong></div>
                    <div className="text-[7.5px] text-purple-400/80 font-mono">
                      {"█".repeat(Math.min(10, Math.round((30 - SHIP_CONFIGS[selectedShip].shootCooldown) / 2)))}
                      {"░".repeat(Math.max(0, 10 - Math.round((30 - SHIP_CONFIGS[selectedShip].shootCooldown) / 2)))}
                    </div>
                  </div>
                  <div className="space-y-0.5">
                    <div>PODER: <strong className="text-gray-300">{SHIP_CONFIGS[selectedShip].laserPower}x</strong></div>
                    <div className="text-[7.5px] text-amber-400/80 font-mono">
                      {"█".repeat(Math.min(10, Math.round(SHIP_CONFIGS[selectedShip].laserPower * 5)))}
                      {"░".repeat(Math.max(0, 10 - Math.round(SHIP_CONFIGS[selectedShip].laserPower * 5)))}
                    </div>
                  </div>
                  <div className="space-y-0.5">
                    <div>TIPO TIRO: <strong className="text-gray-300">{SHIP_CONFIGS[selectedShip].fireType === 'SPREAD' ? 'TRIPLO' : SHIP_CONFIGS[selectedShip].fireType === 'DUAL' ? 'DUPLO' : SHIP_CONFIGS[selectedShip].fireType === 'HEAVY' ? 'PESADO' : 'FOCADO'}</strong></div>
                    <div className="text-[7.5px] text-emerald-400/80 font-mono">
                      {SHIP_CONFIGS[selectedShip].fireType === 'SPREAD' ? '████████░░' : SHIP_CONFIGS[selectedShip].fireType === 'DUAL' ? '██████░░░░' : SHIP_CONFIGS[selectedShip].fireType === 'HEAVY' ? '████░░░░░░' : '██░░░░░░░░'}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="w-full max-w-xs space-y-3">
              <button 
                onClick={() => {
                  initLevel(startLevel, true);
                  // Trigger audios
                  SoundEngine.playLevelSuccess();
                }}
                className="w-full py-3 px-6 rounded-lg bg-gradient-to-r from-amber-500 to-orange-600 text-black font-extrabold text-sm tracking-wide shadow-lg shadow-amber-500/20 hover:from-amber-400 hover:to-orange-500 active:scale-95 cursor-pointer flex items-center justify-center gap-2 uppercase transition duration-200"
                id="btn_play_galaga"
              >
                <Play className="w-4 h-4 fill-current" /> Começar Jogo
              </button>

              <button 
                onClick={() => {
                  setGameState('HOW_TO_PLAY');
                }}
                className="w-full py-2 px-6 rounded-lg border border-gray-800 bg-gray-900 text-gray-300 font-bold text-xs hover:bg-gray-800 active:scale-95 cursor-pointer transition uppercase"
                id="btn_guide_galaga"
              >
                Como Jogar
              </button>

              <button 
                onClick={() => {
                  setShowDownloadModal(true);
                  if (typeof navigator !== 'undefined' && navigator.vibrate) navigator.vibrate(12);
                }}
                className="w-full py-2 px-6 rounded-lg border border-teal-800/40 bg-teal-950/20 text-teal-400 font-bold text-xs hover:bg-teal-950/40 active:scale-95 cursor-pointer transition uppercase flex items-center justify-center gap-1.5"
                id="btn_download_modal_trigger"
              >
                <Smartphone className="w-3.5 h-3.5" /> Baixar no Celular / PC
              </button>
            </div>

            {/* Android performance hint */}
            <div className="mt-12 text-gray-500 text-[10px] font-mono flex items-center gap-1 opacity-70">
              <Smartphone className="w-3.5 h-3.5" /> Totalmente Otimizado para Celulares (Android/iOS)
            </div>
          </div>
        )}

        {/* HOW TO PLAY PANEL */}
        {gameState === 'HOW_TO_PLAY' && (
          <div className="absolute inset-0 bg-gray-950/95 overflow-y-auto p-6 flex flex-col justify-center text-xs font-sans text-left select-none" id="game_how_to_play_overlay">
            <h2 className="text-2xl font-bold text-amber-400 uppercase text-center mb-5 tracking-tight flex items-center justify-center gap-1.5 font-sans">
              ★ COMO JOGAR ★
            </h2>

            <div className="space-y-4 max-w-sm mx-auto text-gray-300">
              <div className="p-3 bg-gray-900/60 rounded-lg border border-amber-500/10 space-y-1">
                <span className="font-bold text-amber-300 block text-[11px] uppercase">🎮 CONTROLE NO ANDROID (CELULAR)</span>
                <p className="leading-relaxed text-gray-400 text-[10.5px]">
                  <b>Toque e arraste</b> o dedo na tela para mover a nave instantaneamente. Deixe o <b>Disparo Automático</b> ativado para focar em desviar dos ataques!
                </p>
              </div>

              <div className="p-3 bg-gray-900/60 rounded-lg border border-amber-500/10 space-y-1">
                <span className="font-bold text-amber-300 block text-[11px] uppercase">💻 CONTROLE NO PC</span>
                <p className="leading-relaxed text-gray-400 text-[10.5px]">
                  Use as teclas <span className="px-1.5 py-0.5 bg-gray-800 rounded font-mono text-[9px]">Seta Esquerda</span> / <span className="px-1.5 py-0.5 bg-gray-800 rounded font-mono text-[9px]">A</span> e <span className="px-1.5 py-0.5 bg-gray-800 rounded font-mono text-[9px]">Seta Direita</span> / <span className="px-1.5 py-0.5 bg-gray-800 rounded font-mono text-[9px]">D</span> para guiar a nave. Pressione <span className="px-1.5 py-0.5 bg-gray-800 rounded font-mono text-[9px]">Espaço</span> para disparar os lasers.
                </p>
              </div>

              <div className="p-3 rounded-lg border border-emerald-500/20 bg-emerald-950/15 space-y-1">
                <span className="font-bold text-emerald-400 block text-[11px] uppercase flex items-center gap-1">🚀 MECÂNICA DA NAVE DUPLA (GALAGA!)</span>
                <p className="leading-relaxed text-gray-400 text-[10.5px]">
                  O alienígena <strong className="text-yellow-400">BOSS amarela</strong> da fileira de cima pode descer lançando um <strong className="text-sky-400">Raio Trator azul</strong>. Caso você seja capturado por ele, perderá uma nave. Mas se depois você <b>destruir o mesmo Boss enquanto ele faz voos rasantes</b>, sua nave capturada será libertada e se acoplará à sua nave atual formando uma <b>Nave Dupla</b> agressiva com poder de fogo dobrado!
                </p>
              </div>
            </div>

            <div className="mt-8 text-center">
              <button 
                onClick={() => setGameState('INTRO')}
                className="py-2.5 px-8 rounded-lg bg-amber-500 text-black font-extrabold text-xs uppercase cursor-pointer hover:bg-amber-400 transition"
              >
                Voltar
              </button>
            </div>
          </div>
        )}

        {/* DOWNLOAD / PLAY ON MOBILE & PC MODAL */}
        {showDownloadModal && (
          <div className="absolute inset-0 bg-gray-950/98 overflow-y-auto p-5 flex flex-col justify-center items-center z-40 select-none animate-fade-in" id="download_game_overlay">
            <div className="w-full max-w-sm space-y-4 text-center">
              
              {/* Header */}
              <div className="space-y-1">
                <div className="flex items-center justify-center gap-2 text-teal-400">
                  <QrCode className="w-6 h-6 animate-pulse" />
                  <h2 className="text-xl font-black uppercase tracking-tight font-sans">
                    Jogar no Celular e PC
                  </h2>
                </div>
                <p className="text-gray-400 text-[10px] font-mono">
                  Sincronização instantânea e suporte completo a controles touch
                </p>
              </div>

              {/* QR Code Container */}
              <div className="bg-black/40 border border-teal-500/10 p-4 rounded-2xl flex flex-col items-center justify-center gap-3 relative shadow-inner">
                <span className="text-[9px] font-mono text-teal-400/80 uppercase tracking-widest font-bold text-center">Escaneie para Android & iOS</span>
                
                <div className="p-2.5 bg-white rounded-xl shadow-lg border-2 border-teal-500/20">
                  <img 
                    src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent("https://ais-pre-hqfgedyb4pbojlzkxcvu6l-308816692911.us-east5.run.app")}`}
                    alt="Android QR Code Link"
                    className="w-[150px] h-[150px]"
                    referrerPolicy="no-referrer"
                  />
                </div>
                
                {/* Instant Link / Copy Link Section */}
                <div className="w-full space-y-2 pt-1 font-mono">
                  <div className="text-[8px] text-gray-500 uppercase text-center">Link de Compartilhamento</div>
                  <div className="flex items-center gap-1.5 p-1.5 bg-gray-900 border border-white/5 rounded-lg text-[9px] text-gray-300">
                    <span className="truncate flex-1 text-left select-all pl-1">
                      https://ais-pre-hqfgedyb4pbojlzkxcvu6l-308816692911.us-east5.run.app
                    </span>
                    <button 
                      onClick={() => {
                        navigator.clipboard.writeText("https://ais-pre-hqfgedyb4pbojlzkxcvu6l-308816692911.us-east5.run.app");
                        setCopied(true);
                        SoundEngine.playLaser(); // Sound effect
                        setTimeout(() => setCopied(false), 2000);
                      }}
                      className="p-1 px-2 rounded bg-teal-500 hover:bg-teal-400 text-black font-bold uppercase transition flex items-center gap-1 cursor-pointer"
                      style={{ fontSize: '8px' }}
                    >
                      {copied ? <Check className="w-2.5 h-2.5" /> : <Copy className="w-2.5 h-2.5" />}
                      {copied ? "Copiado!" : "Copiar"}
                    </button>
                  </div>
                </div>
              </div>

              {/* Actionable Steps for Native Play */}
              <div className="text-left space-y-2.5">
                <div className="p-2.5 bg-gray-900/60 rounded-xl border border-white/5 flex gap-2.5 items-start">
                  <Smartphone className="w-5 h-5 text-teal-400 shrink-0 mt-0.5" />
                  <div className="space-y-0.5 text-[10px]">
                    <span className="font-extrabold text-teal-300 uppercase block">📱 Jogabilidade no Android / iOS (PWA):</span>
                    <p className="leading-relaxed text-gray-400 text-[9.5px]">
                      Escaneie e abra no navegador do seu smartphone. No menu (três pontos do Safari/Chrome), selecione <strong>"Adicionar à Tela de Início"</strong>. O jogo se tornará um app nativo que abre em tela cheia sem barras de navegação!
                    </p>
                  </div>
                </div>

                <div className="p-2.5 bg-gray-900/60 rounded-xl border border-white/5 flex gap-2.5 items-start">
                  <Download className="w-5 h-5 text-teal-400 shrink-0 mt-0.5" />
                  <div className="space-y-0.5 text-[10px]">
                    <span className="font-extrabold text-teal-300 uppercase block">💻 Salvar / Baixar para PC:</span>
                    <p className="leading-relaxed text-gray-400 text-[9.5px]">
                      Acesse o link do jogo no navegador do seu Computador. Para jogar de forma 100% offline, aperte <kbd className="px-1 py-0.5 bg-gray-800 rounded font-mono text-[8px]">Ctrl + S</kbd> e salve o arquivo como "Página Completa". Você poderá abrir e jogar a qualquer momento mesmo sem internet!
                    </p>
                  </div>
                </div>
              </div>

              {/* Close Button */}
              <div className="pt-2 text-center">
                <button 
                  onClick={() => {
                    setShowDownloadModal(false);
                    SoundEngine.playDualShipMerge();
                  }}
                  className="py-2.5 px-8 rounded-lg bg-teal-500 text-black font-extrabold text-xs uppercase cursor-pointer hover:bg-teal-400 active:scale-95 transition"
                >
                  Voltar ao Menu
                </button>
              </div>

            </div>
          </div>
        )}

        {/* HIGH SCORE FORM COMPONENT OVERLAY */}
        {showHighScoreForm && (
          <div className="absolute inset-0 bg-gray-950/95 flex flex-col justify-center items-center p-6 z-30" id="high_score_form_overlay">
            <Award className="w-12 h-12 text-yellow-400 animate-pulse mb-3" />
            <h3 className="text-xl font-black text-white mt-1 uppercase">Novo Recorde Pessoal!</h3>
            <p className="text-yellow-500 text-[13px] font-bold font-mono mt-0.5 mb-5">{score} PONTOS</p>

            <form onSubmit={saveHighScore} className="w-full max-w-xs space-y-3">
              <label className="block text-gray-400 text-center text-xs">Digite seu nome ou iniciais:</label>
              <input 
                type="text"
                maxLength={10}
                required
                value={playerName}
                onChange={e => setPlayerName(e.target.value)}
                placeholder="Ex: PILOTO, RETRO, ALIEN"
                className="w-full bg-gray-900 border border-gray-800 text-white rounded-lg p-2.5 text-center text-sm font-bold placeholder-gray-600 focus:outline-none focus:border-amber-500 uppercase"
                autoFocus
              />
              <button 
                type="submit"
                className="w-full bg-gradient-to-r from-amber-500 to-orange-500 text-black font-bold py-2.5 rounded-lg text-xs uppercase cursor-pointer hover:bg-amber-400 transition"
              >
                Registrar no Ranking
              </button>
            </form>
          </div>
        )}

        {/* GAMEOVER OVERLAY */}
        {gameState === 'GAMEOVER' && !showHighScoreForm && (
          <div className="absolute inset-0 bg-gray-950/95 flex flex-col items-center justify-center p-6 text-center select-none animate-fade-in" id="game_gameover_overlay">
            <h2 className="text-4xl font-extrabold text-red-500 tracking-tighter uppercase font-sans">
              GAME OVER
            </h2>
            <p className="text-gray-400 font-mono text-xs mt-1 mb-8">Nave destruída e tripulação perdida no vácuo espacial.</p>

            <div className="p-4 bg-gray-900/60 rounded-xl border border-gray-800 w-full max-w-xs mb-8 space-y-2 font-mono">
              <div className="flex justify-between items-center text-xs">
                <span className="text-gray-500">PONTUAÇÃO FINAL:</span>
                <span className="text-amber-400 font-bold">{score} PONTOS</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-gray-500">FASE ALCANÇADA:</span>
                <span className="text-blue-400 font-bold">FASE {level}</span>
              </div>
              <div className="flex justify-between items-center text-xs pt-1 border-t border-gray-800">
                <span className="text-gray-500">PRECISÃO DE TIRO:</span>
                <span className="text-emerald-400 font-bold">
                  {stateRef.current.shotsFired > 0 
                    ? `${Math.round((stateRef.current.shotsHit / stateRef.current.shotsFired) * 100)}%` 
                    : '0%'}
                </span>
              </div>
            </div>

            <div className="w-full max-w-xs space-y-3">
              <button 
                onClick={startNewGame}
                className="w-full py-3 px-6 rounded-lg bg-amber-500 text-black font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 hover:bg-amber-400 active:scale-95 cursor-pointer transition duration-150"
                id="btn_replay_galaga"
              >
                <RotateCcw className="w-4 h-4" /> Jogar Novamente
              </button>

              <button 
                onClick={() => {
                  setGameState('INTRO');
                }}
                className="w-full py-2 px-6 rounded-lg border border-gray-800 bg-gray-900 text-gray-400 font-bold text-xs uppercase hover:text-white hover:bg-gray-800 active:scale-95 cursor-pointer transition"
                id="btn_back_to_title_galaga"
              >
                Menu Principal
              </button>
            </div>
          </div>
        )}
      </div>

      {/* 3. MOBILE CONTROLS BOARD (OPTIMIZED FOR CELULAR AND DESKTOP IFRAME TESTING) */}
      {(isMobile || forceShowControls) && gameState === 'PLAYING' && (
        <div className="w-full max-w-[450px] glass-panel rounded-xl p-3.5 mt-4 text-xs select-none shadow-xl border border-cyan-500/20" id="android-controller-board">
          {/* Controls category toggler */}
          <div className="flex justify-between items-center mb-3 pb-2 border-b border-cyan-500/10">
            <div className="flex flex-col gap-0.5">
              <span className="text-cyan-400 font-bold font-mono uppercase text-[10px] tracking-wider flex items-center gap-1" style={{ textShadow: '0 0 6px rgba(0, 210, 255, 0.4)' }}>
                <Smartphone className="w-3.5 h-3.5 animate-pulse" /> Controles Celular
              </span>
              <span className="text-[8px] text-gray-500 font-mono uppercase">Vibração & Toques Ativos</span>
            </div>
            
            <div className="flex gap-1.5 items-center">
              <button 
                onClick={() => {
                  setControlType('DRAG');
                  stateRef.current.touchX = null;
                }}
                className={`py-1 px-2.5 rounded font-bold transition flex items-center gap-1 cursor-pointer text-[10px] uppercase ${controlType === 'DRAG' ? 'bg-cyan-500 text-black shadow-md shadow-cyan-500/30' : 'bg-white/[0.04] border border-white/10 text-gray-400 hover:text-white'}`}
                id="ctl_drag_toggle"
              >
                <Touchpad className="w-3 h-3" /> Arrastar
              </button>
              <button 
                onClick={() => {
                  setControlType('BUTTONS');
                  stateRef.current.touchX = null;
                }}
                className={`py-1 px-2.5 rounded font-bold transition flex items-center gap-1 cursor-pointer text-[10px] uppercase ${controlType === 'BUTTONS' ? 'bg-cyan-500 text-black shadow-md shadow-cyan-500/30' : 'bg-white/[0.04] border border-white/10 text-gray-400 hover:text-white'}`}
                id="ctl_buttons_toggle"
              >
                <Gamepad2 className="w-3 h-3" /> Botões
              </button>

              <button
                onClick={() => setForceShowControls(false)}
                className="ml-1 p-1 text-gray-500 hover:text-rose-405 transition cursor-pointer"
                title="Ocultar botões na tela"
              >
                ✕
              </button>
            </div>
          </div>

          {/* DRAG MODE MANUAL INSTRUCTION */}
          {controlType === 'DRAG' && (
            <div className="flex flex-col items-center justify-center py-2 bg-white/[0.02] border border-cyan-500/10 rounded-lg space-y-1 font-mono">
              <div className="flex items-center gap-3">
                <span className="text-gray-400 text-[10.5px] text-center px-2">Deslize o dedo ou mouse sobre o jogo para guiar a nave!</span>
              </div>
              
              <div className="flex items-center gap-2 pt-1">
                <span className="text-[10px] text-gray-500">DISPARO AUTOMÁTICO:</span>
                <button
                  onClick={() => {
                    setAutoShoot(!autoShoot);
                    if (typeof navigator !== 'undefined' && navigator.vibrate) navigator.vibrate(10);
                  }}
                  className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase transition ${autoShoot ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-rose-500/20 text-rose-400 border border-rose-500/20'}`}
                >
                  {autoShoot ? 'ATIVADO' : 'DESATIVADO'}
                </button>
              </div>
            </div>
          )}

          {/* DIRECT PHYSICAL D-PAD CONTROLS */}
          {controlType === 'BUTTONS' && (
            <div className="flex justify-between items-center py-2 px-1 select-none" id="android-tactile-joystick">
              {/* Steer controls */}
              <div className="flex gap-3">
                <button 
                  onTouchStart={(e) => { e.preventDefault(); leftPressed.current = true; if (typeof navigator !== 'undefined' && navigator.vibrate) navigator.vibrate(10); }}
                  onTouchEnd={(e) => { e.preventDefault(); leftPressed.current = false; }}
                  onMouseDown={(e) => { e.preventDefault(); leftPressed.current = true; }}
                  onMouseUp={() => { leftPressed.current = false; }}
                  onMouseLeave={() => { leftPressed.current = false; }}
                  className="w-16 h-16 rounded-full bg-white/[0.04] active:bg-cyan-500/25 border-2 border-cyan-500/20 hover:border-cyan-500/40 text-cyan-400 active:text-cyan-300 active:scale-90 flex items-center justify-center shadow-lg hover:bg-white/[0.08] transition duration-150 select-none touch-none cursor-pointer"
                  style={{ textShadow: '0 0 8px rgba(0, 210, 255, 0.4)' }}
                  title="Mover para esquerda"
                >
                  <ChevronLeft className="w-8 h-8 stroke-[2.5]" />
                </button>
                <button 
                  onTouchStart={(e) => { e.preventDefault(); rightPressed.current = true; if (typeof navigator !== 'undefined' && navigator.vibrate) navigator.vibrate(10); }}
                  onTouchEnd={(e) => { e.preventDefault(); rightPressed.current = false; }}
                  onMouseDown={(e) => { e.preventDefault(); rightPressed.current = true; }}
                  onMouseUp={() => { rightPressed.current = false; }}
                  onMouseLeave={() => { rightPressed.current = false; }}
                  className="w-16 h-16 rounded-full bg-white/[0.04] active:bg-cyan-500/25 border-2 border-cyan-500/20 hover:border-cyan-500/40 text-cyan-400 active:text-cyan-300 active:scale-90 flex items-center justify-center shadow-lg hover:bg-white/[0.08] transition duration-150 select-none touch-none cursor-pointer"
                  style={{ textShadow: '0 0 8px rgba(0, 210, 255, 0.4)' }}
                  title="Mover para direita"
                >
                  <ChevronRight className="w-8 h-8 stroke-[2.5]" />
                </button>
              </div>

              {/* Utility and Fire Actions */}
              <div className="flex items-center gap-4">
                {/* Auto Shoot switch */}
                <div className="flex flex-col items-center">
                  <span className="text-[8px] text-gray-500 font-mono mb-1">AUTO DISPARO</span>
                  <button
                    onClick={() => {
                      setAutoShoot(!autoShoot);
                      if (typeof navigator !== 'undefined' && navigator.vibrate) navigator.vibrate(12);
                    }}
                    className={`px-2.5 py-1.5 rounded-lg text-[9px] font-bold uppercase transition duration-150 active:scale-95 cursor-pointer ${
                      autoShoot 
                        ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-400' 
                        : 'bg-white/[0.04] border border-white/10 text-gray-400 font-medium'
                    }`}
                  >
                    {autoShoot ? 'SIM' : 'NÃO'}
                  </button>
                </div>

                {/* Fire laser button specs */}
                <div className="flex flex-col items-end">
                  <button 
                    onTouchStart={(e) => { e.preventDefault(); shootPressed.current = true; if (typeof navigator !== 'undefined' && navigator.vibrate) navigator.vibrate(15); }}
                    onTouchEnd={(e) => { e.preventDefault(); shootPressed.current = false; }}
                    onMouseDown={(e) => { e.preventDefault(); shootPressed.current = true; }}
                    onMouseUp={() => { shootPressed.current = false; }}
                    onMouseLeave={() => { shootPressed.current = false; }}
                    className="w-20 h-16 rounded-2xl bg-rose-600/20 hover:bg-rose-600/35 active:bg-rose-500/40 border-2 border-rose-500 text-rose-400 active:text-white font-extrabold flex flex-col items-center justify-center active:scale-90 shadow-lg shadow-rose-500/10 transition duration-150 select-none touch-none cursor-pointer"
                    style={{ textShadow: '0 0 8px #f43f5e' }}
                  >
                    <Zap className="w-5 h-5 fill-current animate-pulse mb-0.5 text-rose-400" />
                    <span className="text-[10px] tracking-wide font-mono font-extrabold">ATIRAR</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Touch controls activate float button for PC testers when closed */}
      {!forceShowControls && gameState === 'PLAYING' && (
        <button
          onClick={() => {
            setForceShowControls(true);
            if (typeof navigator !== 'undefined' && navigator.vibrate) navigator.vibrate(20);
          }}
          className="mt-3 text-[10px] font-mono uppercase font-bold tracking-wider text-cyan-400 hover:text-cyan-300 py-1.5 px-3 bg-cyan-500/5 hover:bg-cyan-500/10 border border-cyan-500/15 hover:border-cyan-500/30 rounded-lg shadow-sm transition duration-150 active:scale-95 cursor-pointer flex items-center justify-center gap-1.5"
          style={{ textShadow: '0 0 5px rgba(0, 210, 255, 0.3)' }}
        >
          <Gamepad2 className="w-3.5 h-3.5 animate-pulse" /> Ativar Controles Virtuais
        </button>
      )}

      {/* 4. KEYBOARD HINTS PREVIEWS ON DESKTOP */}
      {!(isMobile || forceShowControls) && gameState === 'PLAYING' && (
        <div className="mt-4 text-center font-mono text-[10.5px] text-gray-500" id="desktop-keyboard-hint">
          <span>⌨ Dicas do Teclado:</span> <span className="text-gray-400">[← / A]</span> ir para esquerda • <span className="text-gray-400">[→ / D]</span> ir para direita • <span className="text-gray-400">[Espaço]</span> disparar laser
        </div>
      )}
    </div>
  );
}

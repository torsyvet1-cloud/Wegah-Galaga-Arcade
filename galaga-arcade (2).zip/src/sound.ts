/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

class SoundEffectsManager {
  private ctx: AudioContext | null = null;
  private muted: boolean = false;

  // Retro Music Loop Variables
  private musicPlaying: boolean = false;
  private musicVolume: number = 0.35; // Default volume (0.0 to 1.0)
  private musicGainNode: GainNode | null = null;
  private schedulerTimerId: any = null;
  private currentStep: number = 0;
  private nextEventTime: number = 0;
  private readonly scheduleAheadTime: number = 0.12; // seconds
  private readonly lookahead: number = 25.0; // ms

  // G minor cosmic sequence frequencies for 32 steps (8th notes at ~125 BPM)
  private readonly bassPitches: number[] = [
    // Gm chord steps 0-7
    98.00, 196.00, 98.00, 196.00, 98.00, 196.00, 98.00, 196.00,
    // Eb chord steps 8-15
    77.78, 155.56, 77.78, 155.56, 77.78, 155.56, 77.78, 155.56,
    // F chord steps 16-23
    87.31, 174.61, 87.31, 174.61, 87.31, 174.61, 87.31, 174.61,
    // D chord steps 24-31
    73.42, 146.83, 73.42, 146.83, 73.42, 146.83, 73.42, 146.83
  ];

  private readonly melodyPitches: number[] = [
    // Gm
    392.00, 0, 466.16, 0, 587.33, 0, 466.16, 587.33,
    // Eb
    392.00, 0, 466.16, 0, 622.25, 0, 466.16, 622.25,
    // F
    440.00, 0, 523.25, 0, 698.46, 0, 523.25, 698.46,
    // D
    369.99, 0, 440.00, 0, 587.33, 0, 293.66, 369.99
  ];

  constructor() {
    // AudioContext will be created lazily upon user interaction to avoid browser warnings
  }

  private init() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtxClass) {
        this.ctx = new AudioCtxClass();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public setMuted(muted: boolean) {
    this.muted = muted;
    this.updateMusicVolume();
  }

  public isMuted() {
    return this.muted;
  }

  public toggleMute() {
    this.muted = !this.muted;
    this.updateMusicVolume();
    return this.muted;
  }

  // --- RETRO SYNTH MUSIC CONTROLLER ---
  public startMusic() {
    if (this.musicPlaying) return;
    this.init();
    if (!this.ctx) return;

    this.musicPlaying = true;

    if (!this.musicGainNode) {
      this.musicGainNode = this.ctx.createGain();
      this.musicGainNode.connect(this.ctx.destination);
    }

    this.updateMusicVolume();

    this.currentStep = 0;
    this.nextEventTime = this.ctx.currentTime + 0.05;

    const scheduler = () => {
      if (!this.musicPlaying || !this.ctx) return;
      while (this.nextEventTime < this.ctx.currentTime + this.scheduleAheadTime) {
        this.scheduleStep(this.currentStep, this.nextEventTime);
        this.currentStep++;
        // 125 BPM 8th notes -> 0.24 seconds per step
        this.nextEventTime += 0.24;
      }
      this.schedulerTimerId = setTimeout(scheduler, this.lookahead);
    };

    scheduler();
  }

  public stopMusic() {
    this.musicPlaying = false;
    if (this.schedulerTimerId) {
      clearTimeout(this.schedulerTimerId);
      this.schedulerTimerId = null;
    }
  }

  public isMusicPlaying() {
    return this.musicPlaying;
  }

  public setMusicVolume(volume: number) {
    this.musicVolume = Math.max(0, Math.min(1, volume));
    this.updateMusicVolume();
  }

  public getMusicVolume() {
    return this.musicVolume;
  }

  private updateMusicVolume() {
    if (this.ctx && this.musicGainNode) {
      const actualVolume = this.muted ? 0 : this.musicVolume * 0.15; // Scaled down to be a nice background levels
      this.musicGainNode.gain.setValueAtTime(actualVolume, this.ctx.currentTime);
    }
  }

  private scheduleStep(stepIndex: number, time: number) {
    if (!this.ctx || !this.musicGainNode || this.muted) return;

    // Bass Note synthesis
    const bassFreq = this.bassPitches[stepIndex % 32];
    if (bassFreq > 0) {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();

      // Fun retro synth sound: triangle/sawtooth
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(bassFreq, time);

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(320, time);

      // Volume envelope
      gain.gain.setValueAtTime(0, time);
      gain.gain.linearRampToValueAtTime(0.48, time + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, time + 0.22);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.musicGainNode);

      osc.start(time);
      osc.stop(time + 0.24);
    }

    // Melody Note synthesis
    const melFreq = this.melodyPitches[stepIndex % 32];
    if (melFreq > 0) {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(melFreq, time);

      // Cute delicate melody sound
      gain.gain.setValueAtTime(0, time);
      gain.gain.linearRampToValueAtTime(0.18, time + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.001, time + 0.21);

      osc.connect(gain);
      gain.connect(this.musicGainNode);

      osc.start(time);
      osc.stop(time + 0.24);
    }
  }

  public playLaser() {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(880, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(110, this.ctx.currentTime + 0.15);

    gain.gain.setValueAtTime(0.2, this.ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0.01, this.ctx.currentTime + 0.15);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start();
    osc.stop(this.ctx.currentTime + 0.15);
  }

  public playEnemyLaser() {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(440, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(80, this.ctx.currentTime + 0.22);

    gain.gain.setValueAtTime(0.08, this.ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0.001, this.ctx.currentTime + 0.22);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start();
    osc.stop(this.ctx.currentTime + 0.22);
  }

  public playExplosion() {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;

    // Simulate explosion check with filtered noise or a rapid sawtooth decay
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(150, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(20, this.ctx.currentTime + 0.35);

    // Add a second oscillator for crunchy low detune
    const osc2 = this.ctx.createOscillator();
    osc2.type = 'sawtooth';
    osc2.frequency.setValueAtTime(100, this.ctx.currentTime);
    osc2.frequency.linearRampToValueAtTime(10, this.ctx.currentTime + 0.35);

    gain.gain.setValueAtTime(0.3, this.ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0.001, this.ctx.currentTime + 0.35);

    osc.connect(gain);
    osc2.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start();
    osc2.start();
    osc.stop(this.ctx.currentTime + 0.35);
    osc2.stop(this.ctx.currentTime + 0.35);
  }

  public playBossHit() {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(220, this.ctx.currentTime);
    osc.frequency.setValueAtTime(330, this.ctx.currentTime + 0.04);

    gain.gain.setValueAtTime(0.15, this.ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0.01, this.ctx.currentTime + 0.08);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start();
    osc.stop(this.ctx.currentTime + 0.08);
  }

  public playTractorBeam() {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    // Rising sweep representing high tech tractor pull
    const now = this.ctx.currentTime;
    osc.frequency.setValueAtTime(200, now);
    osc.frequency.linearRampToValueAtTime(600, now + 0.25);

    gain.gain.setValueAtTime(0.1, now);
    gain.gain.linearRampToValueAtTime(0.01, now + 0.25);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start();
    osc.stop(now + 0.25);
  }

  public playLevelSuccess() {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    const notes = [261.63, 329.63, 392.00, 523.25, 392.00, 523.25, 659.25]; // C4, E4, G4, C5, G4, C5, E5
    const duration = 0.09;

    notes.forEach((note, i) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();

      osc.type = 'square';
      osc.frequency.setValueAtTime(note, now + i * duration);

      gain.gain.setValueAtTime(0.12, now + i * duration);
      gain.gain.linearRampToValueAtTime(0.001, now + (i + 1) * duration);

      osc.connect(gain);
      gain.connect(this.ctx!.destination);

      osc.start(now + i * duration);
      osc.stop(now + (i + 1) * duration);
    });
  }

  public playShipCaptured() {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    const notes = [440, 415.3, 392, 349.23, 293.66, 220]; // Melancholic downward dive
    const duration = 0.15;

    notes.forEach((note, i) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(note, now + i * duration);

      gain.gain.setValueAtTime(0.1, now + i * duration);
      gain.gain.linearRampToValueAtTime(0.001, now + (i + 1) * duration);

      osc.connect(gain);
      gain.connect(this.ctx!.destination);

      osc.start(now + i * duration);
      osc.stop(now + (i + 1) * duration);
    });
  }

  public playDualShipMerge() {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    const notes = [293.66, 349.23, 440, 523.25, 587.33, 698.46, 880]; // Triumphant upward synth arpeggio
    const duration = 0.08;

    notes.forEach((note, i) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(note, now + i * duration);

      gain.gain.setValueAtTime(0.15, now + i * duration);
      gain.gain.linearRampToValueAtTime(0.001, now + (i * duration) + 0.2);

      osc.connect(gain);
      gain.connect(this.ctx!.destination);

      osc.start(now + i * duration);
      osc.stop(now + (i * duration) + 0.25);
    });
  }

  public playGameOver() {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    const notes = [196.00, 185.00, 174.61, 146.83, 110.00, 73.42]; // Descending chromatic doom
    const duration = 0.2;

    notes.forEach((note, i) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(note, now + i * duration);

      gain.gain.setValueAtTime(0.12, now + i * duration);
      gain.gain.linearRampToValueAtTime(0.001, now + (i + 1) * duration);

      osc.connect(gain);
      gain.connect(this.ctx!.destination);

      osc.start(now + i * duration);
      osc.stop(now + (i + 1) * duration);
    });
  }
}

export const SoundEngine = new SoundEffectsManager();

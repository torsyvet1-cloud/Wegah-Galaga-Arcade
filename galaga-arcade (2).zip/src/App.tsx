/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import GalagaGame from './components/GalagaGame';
import { HighScore } from './types';
import { Award, ShieldAlert, Sparkles, Sword, Play, RefreshCw, Star, Info, Volume2, VolumeX, Music, HelpCircle, QrCode, Download, Smartphone, X, Tv } from 'lucide-react';
import { SoundEngine } from './sound';

const DEFAULT_SCORES: HighScore[] = [
  { name: "RETRO_KING", score: 8500, date: "29/05/2026" },
  { name: "SKYWALKER", score: 6200, date: "28/05/2026" },
  { name: "SOLO", score: 4800, date: "15/05/2026" },
  { name: "R2D2", score: 3100, date: "12/05/2026" },
  { name: "PILOTO", score: 1500, date: "10/05/2026" },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'GAME' | 'LEADERBOARD' | 'ABOUT'>('GAME');
  const [highScores, setHighScores] = useState<HighScore[]>([]);
  const [currentScore, setCurrentScore] = useState(0);
  const [showDownloadModal, setShowDownloadModal] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  const [musicVol, setMusicVol] = useState(SoundEngine.getMusicVolume());
  const [isMusicPlayingState, setIsMusicPlayingState] = useState(false);

  const [scanlineType, setScanlineType] = useState<'CLASSIC' | 'SHARP' | 'MONOCHROME' | 'OFF'>(() => {
    const saved = localStorage.getItem('galaga_arcade_scanline_type');
    return (saved as any) || 'CLASSIC';
  });

  const handleScanlineTypeChange = (type: 'CLASSIC' | 'SHARP' | 'MONOCHROME' | 'OFF') => {
    setScanlineType(type);
    localStorage.setItem('galaga_arcade_scanline_type', type);
  };

  // Synchronize playing state
  useEffect(() => {
    const timer = setInterval(() => {
      setIsMusicPlayingState(SoundEngine.isMusicPlaying());
    }, 250);
    return () => clearInterval(timer);
  }, []);

  // Play music on first interaction
  useEffect(() => {
    const handleInitialInteraction = () => {
      SoundEngine.startMusic();
      setIsMusicPlayingState(true);
      window.removeEventListener('click', handleInitialInteraction);
      window.removeEventListener('keydown', handleInitialInteraction);
    };

    window.addEventListener('click', handleInitialInteraction);
    window.addEventListener('keydown', handleInitialInteraction);

    return () => {
      window.removeEventListener('click', handleInitialInteraction);
      window.removeEventListener('keydown', handleInitialInteraction);
    };
  }, []);

  const handleVolumeSliderChange = (val: number) => {
    SoundEngine.setMusicVolume(val);
    setMusicVol(val);
  };

  const togglePlayMusic = () => {
    if (SoundEngine.isMusicPlaying()) {
      SoundEngine.stopMusic();
      setIsMusicPlayingState(false);
    } else {
      SoundEngine.startMusic();
      setIsMusicPlayingState(true);
    }
  };

  // Load high scores on mount
  useEffect(() => {
    const handleBeforeInstall = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);

    const storedScores = localStorage.getItem('galaga_arcade_scores');
    if (storedScores) {
      try {
        setHighScores(JSON.parse(storedScores));
      } catch {
        setHighScores(DEFAULT_SCORES);
      }
    } else {
      localStorage.setItem('galaga_arcade_scores', JSON.stringify(DEFAULT_SCORES));
      setHighScores(DEFAULT_SCORES);
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
    };
  }, []);

  const triggerInstallPrompt = () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    deferredPrompt.userChoice.then((choiceResult: { outcome: string }) => {
      if (choiceResult.outcome === 'accepted') {
        console.log('User accepted PWA installation');
      }
      setDeferredPrompt(null);
    });
  };

  const addHighScore = (name: string, score: number) => {
    const formattedDate = new Date().toLocaleDateString('pt-BR');
    const newRecord: HighScore = { name: name.toUpperCase(), score, date: formattedDate };
    
    const updated = [...highScores, newRecord]
      .sort((a, b) => b.score - a.score)
      .slice(0, 8); // Keep top 8 scores

    setHighScores(updated);
    localStorage.setItem('galaga_arcade_scores', JSON.stringify(updated));
    setActiveTab('LEADERBOARD');
  };

  const clearScores = () => {
    if (confirm("Tem certeza que deseja redefinir o ranking de recordes?")) {
      localStorage.setItem('galaga_arcade_scores', JSON.stringify(DEFAULT_SCORES));
      setHighScores(DEFAULT_SCORES);
    }
  };

  return (
    <div className="min-h-screen immersive-radial text-white flex flex-col justify-between font-sans selection:bg-cyan-500 selection:text-black" id="retro_arcade_wrapper">
      {/* Immersive background stars overlay and screen glow */}
      <div className="fixed inset-0 pointer-events-none z-0 starfield-overlay" />
      <div className="fixed inset-0 pointer-events-none z-0 opacity-30 select-none bg-[radial-gradient(ellipse_at_top,rgba(0,210,255,0.1),transparent_50%)]" />

      {/* 1. ARCHITECTURAL ARCADE HEADER */}
      <header className="w-full bg-[#020205]/80 border-b border-cyan-500/10 sticky top-0 z-10 backdrop-blur-md px-4 py-3 select-none" id="retro_top_header">
        <div className="max-w-4xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded bg-gradient-to-tr from-cyan-400 to-blue-600 flex items-center justify-center text-black font-extrabold text-xs shadow-lg shadow-cyan-500/20 text-center font-mono animate-pulse">
              GA
            </div>
            <div>
              <span className="text-sm font-extrabold tracking-tight block text-white font-mono" style={{ textShadow: '0 0 8px rgba(0,210,255,0.6)' }}>GALAGA ARCADE</span>
              <span className="text-[10px] text-cyan-400 font-medium block tracking-widest font-mono uppercase">Immersive Android Edition</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <nav className="flex bg-[#020205]/95 p-0.5 rounded-lg border border-cyan-500/20 text-xs font-mono">
              <button 
                onClick={() => setActiveTab('GAME')}
                className={`px-3 py-1.5 rounded-md font-bold transition duration-200 cursor-pointer ${activeTab === 'GAME' ? 'bg-cyan-500 text-black shadow-md shadow-cyan-500/30' : 'text-gray-400 hover:text-white'}`}
                id="nav_btn_game"
              >
                Jogo
              </button>
              <button 
                onClick={() => setActiveTab('LEADERBOARD')}
                className={`px-3 py-1.5 rounded-md font-bold transition duration-200 cursor-pointer flex items-center gap-1 ${activeTab === 'LEADERBOARD' ? 'bg-cyan-500 text-black shadow-md shadow-cyan-500/30' : 'text-gray-400 hover:text-white'}`}
                id="nav_btn_ranking"
              >
                <Award className="w-3.5 h-3.5" /> Ranking
              </button>
              <button 
                onClick={() => setActiveTab('ABOUT')}
                className={`px-3 py-1.5 rounded-md font-bold transition duration-200 cursor-pointer flex items-center gap-1 ${activeTab === 'ABOUT' ? 'bg-cyan-500 text-black shadow-md shadow-cyan-500/30' : 'text-gray-400 hover:text-white'}`}
                id="nav_btn_credits"
              >
                Info
              </button>
            </nav>

            <button 
              onClick={() => setShowDownloadModal(true)}
              className="px-2.5 py-1.5 rounded-lg font-bold transition duration-200 cursor-pointer flex items-center gap-1 bg-cyan-950/20 border border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10 text-xs font-mono"
              id="nav_btn_download_qr"
            >
              <QrCode className="w-3.5 h-3.5 animate-pulse" /> Baixar
            </button>
          </div>
        </div>
      </header>

      {/* 2. DYNAMIC LAYOUT AREA */}
      <main className="flex-grow flex items-center justify-center p-4 z-10" id="retro_main_content">
        <div className="w-full max-w-4xl grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* TAB 1: ACTIVE PLAYING FIELD (TAKES UP MAJOR SPACE) */}
          <div className="lg:col-span-7 flex justify-center w-full">
            {activeTab === 'GAME' && (
              <GalagaGame 
                onBackToMenu={() => setActiveTab('GAME')}
                onSetScore={setCurrentScore}
                highScores={highScores}
                onAddHighScore={addHighScore}
                scanlineType={scanlineType}
              />
            )}

            {/* TAB 2: LEADERBOARD SCREEN */}
            {activeTab === 'LEADERBOARD' && (
              <div className="w-full max-w-[450px] glass-panel p-6 rounded-2xl shadow-2xl relative border-cyan-500/20" id="ranking_board_panel">
                <div className="flex items-center justify-between mb-6 pb-4 border-b border-cyan-500/10">
                  <div className="flex items-center gap-2">
                    <Award className="w-6 h-6 text-cyan-400" />
                    <h2 className="text-xl font-bold tracking-tight text-white uppercase font-mono" style={{ textShadow: '0 0 8px rgba(0,210,255,0.4)' }}>RECORDES DA CABINE</h2>
                  </div>
                  <button 
                    onClick={clearScores}
                    className="p-1 px-2.5 rounded text-[10px] uppercase font-bold tracking-wide border border-rose-500/20 hover:border-rose-500/40 text-rose-400 bg-rose-950/20 cursor-pointer transition active:scale-95 duration-150"
                    title="Redefinir recordes"
                  >
                    Reset
                  </button>
                </div>

                {/* Score listing columns */}
                <div className="space-y-2 max-h-[340px] overflow-y-auto pr-1" id="ranking-list">
                  {highScores.map((record, index) => {
                    let badgeColor = "text-gray-400";
                    let rowBg = "bg-white/[0.02] border border-transparent";
                    if (index === 0) {
                      badgeColor = "text-cyan-400 font-extrabold";
                      rowBg = "bg-cyan-500/5 border border-cyan-500/20";
                    } else if (index === 1) {
                      badgeColor = "text-yellow-400 font-extrabold";
                      rowBg = "bg-yellow-500/5 border border-yellow-500/10";
                    } else if (index === 2) {
                      badgeColor = "text-rose-400 font-extrabold";
                      rowBg = "bg-rose-500/5 border border-rose-500/10";
                    }

                    return (
                      <div key={index} className={`flex justify-between items-center p-3 rounded-lg ${rowBg} transition duration-150 hover:bg-white/[0.05] font-mono text-sm`}>
                        <div className="flex items-center gap-3">
                          <span className={`w-5 text-right font-bold ${badgeColor}`}>
                            #{index + 1}
                          </span>
                          <span className="font-bold text-gray-200 tracking-wide uppercase">
                            {record.name}
                          </span>
                        </div>
                        <div className="flex items-center gap-6">
                          <span className="text-cyan-300 font-extrabold tracking-wider">{record.score}</span>
                          <span className="text-gray-500 text-[10px] hidden sm:inline">{record.date}</span>
                        </div>
                      </div>
                    );
                  })}
                  {highScores.length === 0 && (
                    <div className="text-center py-12 text-gray-400 font-mono text-xs">
                      Nenhum piloto registrado. Comece a jogar para marcar época!
                    </div>
                  )}
                </div>

                <div className="mt-8">
                  <button 
                    onClick={() => setActiveTab('GAME')}
                    className="w-full py-3 bg-cyan-500 text-black font-extrabold tracking-wide text-xs uppercase rounded-lg hover:bg-cyan-400 active:scale-95 transition cursor-pointer shadow-md shadow-cyan-500/10"
                  >
                    Voltar para o Fliperama
                  </button>
                </div>
              </div>
            )}

            {/* TAB 3: ABOUT GAME AND CREDITS */}
            {activeTab === 'ABOUT' && (
              <div className="w-full max-w-[450px] glass-panel p-6 rounded-2xl shadow-2xl space-y-5 border-cyan-500/20" id="info_panel">
                <div className="border-b border-cyan-500/10 pb-3">
                  <h2 className="text-lg font-extrabold uppercase font-mono tracking-tight text-white flex items-center gap-1.5" style={{ textShadow: '0 0 8px rgba(0,210,255,0.4)' }}>
                    <Info className="w-5 h-5 text-cyan-400" /> SOBRE O GALAGA ARCADE
                  </h2>
                </div>

                <div className="space-y-4 text-xs font-sans text-gray-300 leading-relaxed">
                  <div className="p-3 bg-cyan-500/10 backdrop-blur rounded-xl border border-cyan-500/25 text-center shadow-lg shadow-cyan-500/5">
                    <span className="text-[9px] text-gray-400 block tracking-widest font-mono uppercase mb-0.5">Assinatura do Gabinete</span>
                    <span className="text-sm font-extrabold text-cyan-300 font-mono tracking-wide" style={{ textShadow: '0 0 8px rgba(0, 210, 255, 0.5)' }}>CRIADO POR WEGAH</span>
                  </div>

                  <p>
                    Esta é uma reinterpretação sofisticada de <b>Galaga</b>, um dos jogos de tiro espacial mais famosos de todos os tempos. Desenvolvido em <b>React + Canvas de alta precisão </b> para rodar com extrema leveza a 60 frames por segundo em navegadores de computadores e smartphones Android.
                  </p>

                  <div className="p-3 bg-cyan-500/5 rounded-lg border border-cyan-500/10 space-y-2">
                    <span className="font-bold text-cyan-400 text-xs uppercase block">Destaques Criados:</span>
                    <ul className="list-disc pl-4 space-y-1 text-gray-400 text-[11px]">
                      <li>Inimigos que surgem em curvas harmoniosas e se alinham.</li>
                      <li>Vôos rasantes dos alienígenas equipados com armas laser.</li>
                      <li>Mecânica de <b>Raio Trator</b> que captura o caça caso fique parado embaixo.</li>
                      <li>Combinação de <b>Naves Duplas</b> para multiplicar o dano após resgate.</li>
                      <li>Efeitos de som sintetizados nativos (sem arquivos MP3 adicionais).</li>
                    </ul>
                  </div>

                  {/* Renders retro synth music loop controls */}
                  <div className="p-3 bg-cyan-950/20 rounded-xl border border-cyan-500/15 space-y-3 shadow-md">
                    <span className="font-extrabold text-cyan-400 text-[11px] uppercase tracking-wide flex items-center gap-2">
                      <Music className="w-3.5 h-3.5 animate-pulse text-cyan-400" /> TEMA MUSICAL RETRÔ (LOOP)
                    </span>
                    
                    <div className="space-y-2 font-mono text-[10px]">
                      <div className="flex justify-between items-center text-gray-300">
                        <span>VOLUME DO TEMA: {Math.round(musicVol * 100)}%</span>
                        <span className="text-[9px] font-bold text-cyan-400">
                          {musicVol === 0 ? 'MUTADO' : musicVol < 0.35 ? 'SUAVE' : musicVol < 0.70 ? 'MÉDIO' : 'ALTO'}
                        </span>
                      </div>
                      
                      <div className="flex items-center gap-2.5">
                        <button 
                          onClick={() => handleVolumeSliderChange(0)} 
                          className="text-gray-400 hover:text-white transition"
                          title="Mudar para mudo"
                        >
                          <VolumeX className="w-3.5 h-3.5" />
                        </button>
                        <input
                          type="range"
                          min="0"
                          max="1"
                          step="0.05"
                          value={musicVol}
                          onChange={(e) => handleVolumeSliderChange(parseFloat(e.target.value))}
                          className="w-full h-1 bg-cyan-950 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                          style={{
                            backgroundImage: `linear-gradient(to right, rgb(34, 211, 238) ${musicVol * 100}%, rgba(255,255,255,0.05) ${musicVol * 100}%)`
                          }}
                        />
                        <button 
                          onClick={() => handleVolumeSliderChange(0.85)} 
                          className="text-gray-400 hover:text-white transition"
                          title="Aumentar volume"
                        >
                          <Volume2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="flex gap-2 pt-1">
                        <button
                          onClick={togglePlayMusic}
                          className={`w-full py-1.5 rounded-lg text-[9px] uppercase font-extrabold border transition cursor-pointer ${
                            isMusicPlayingState
                              ? 'bg-rose-500/10 text-rose-400 border-rose-500/20 hover:bg-rose-500/20'
                              : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20 hover:bg-emerald-500/20'
                          }`}
                        >
                          {isMusicPlayingState ? 'Pausar Reprodução' : 'Iniciar Reprodução'}
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* CRT SCANLINES & SCREEN FILTER CONTROLLER */}
                  <div className="p-3 bg-cyan-950/20 rounded-xl border border-cyan-500/15 space-y-3 shadow-md">
                    <span className="font-extrabold text-cyan-400 text-[11px] uppercase tracking-wide flex items-center gap-2">
                      <Tv className="w-3.5 h-3.5 text-cyan-400" /> TELA DE TV RETRÔ (CRT)
                    </span>
                    
                    <div className="space-y-2 font-mono text-[10px]">
                      <div className="text-gray-300 uppercase tracking-wider text-[8.5px]">
                        Estilo da Linha/Filtro:
                      </div>
                      
                      <div className="grid grid-cols-4 gap-1">
                        <button
                          onClick={() => handleScanlineTypeChange('CLASSIC')}
                          className={`py-1.5 px-0.5 rounded text-[8px] font-extrabold border transition cursor-pointer text-center ${
                            scanlineType === 'CLASSIC'
                              ? 'bg-cyan-500 text-black border-cyan-400 shadow-md shadow-cyan-500/25'
                              : 'bg-black/40 text-gray-400 border-white/5 hover:text-white'
                          }`}
                        >
                          CLÁSSICO
                        </button>
                        <button
                          onClick={() => handleScanlineTypeChange('SHARP')}
                          className={`py-1.5 px-0.5 rounded text-[8px] font-extrabold border transition cursor-pointer text-center ${
                            scanlineType === 'SHARP'
                              ? 'bg-cyan-500 text-black border-cyan-400 shadow-md shadow-cyan-500/25'
                              : 'bg-black/40 text-gray-400 border-white/5 hover:text-white'
                          }`}
                        >
                          NÍTIDO
                        </button>
                        <button
                          onClick={() => handleScanlineTypeChange('MONOCHROME')}
                          className={`py-1.5 px-0.5 rounded text-[8px] font-extrabold border transition cursor-pointer text-center ${
                            scanlineType === 'MONOCHROME'
                              ? 'bg-cyan-500 text-black border-cyan-400 shadow-md shadow-cyan-500/25'
                              : 'bg-black/40 text-gray-400 border-white/5 hover:text-white'
                          }`}
                        >
                          P3 GREEN
                        </button>
                        <button
                          onClick={() => handleScanlineTypeChange('OFF')}
                          className={`py-1.5 px-0.5 rounded text-[8px] font-extrabold border transition cursor-pointer text-center ${
                            scanlineType === 'OFF'
                              ? 'bg-cyan-500 text-black border-cyan-400 shadow-md shadow-cyan-500/25'
                              : 'bg-black/40 text-gray-400 border-white/5 hover:text-white'
                          }`}
                        >
                          LÍMPIDO
                        </button>
                      </div>
                      <div className="text-[8.5px] text-gray-500 leading-tight">
                        {scanlineType === 'CLASSIC' && 'Simula listras horizontais clássicas de TVs de tubo com cintilação suave.'}
                        {scanlineType === 'SHARP' && 'Scanlines ultrafinas de alta resolução sem brilho de oscilação.'}
                        {scanlineType === 'MONOCHROME' && 'Tela arcade monocromática de fósforo verde com alta densidade de feixe.'}
                        {scanlineType === 'OFF' && 'Remete a telas planas LCD modernas com clareza digital límpida.'}
                      </div>
                    </div>
                  </div>

                  <p className="text-gray-500 text-[11px]">
                    Idealizado para preencher as exigências de jogo rápido no celular e celebrar a era de ouro dos fliperamas dos anos 80.
                  </p>
                </div>

                <button 
                  onClick={() => setActiveTab('GAME')}
                  className="w-full py-2.5 bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 text-white font-bold text-xs uppercase rounded-lg transition active:scale-95 cursor-pointer"
                >
                  Voltar
                </button>
              </div>
            )}
          </div>

          {/* DYNAMIC SIDEBAR (ONLY SHOWN FOR CONTEXTUAL ARCADE FLIPERAMA FEELING ON DESKTOP VIEWS) */}
          <div className="lg:col-span-5 space-y-5 hidden lg:block" id="desktop_cabin_art">
            
            {/* Retro Flyer Advert Box */}
            <div className="relative overflow-hidden glass-panel border-cyan-500/20 rounded-2xl p-5 shadow-xl">
              <div className="absolute top-0 right-0 p-3 text-cyan-500/5 pointer-events-none select-none">
                <Sword className="w-24 h-24 stroke-[1.5]" />
              </div>

              <span className="text-[10px] text-cyan-400 font-bold tracking-widest block uppercase mb-1 font-mono">Batalha no Espaço</span>
              <h3 className="text-lg font-black text-white leading-tight uppercase font-mono" style={{ textShadow: '0 0 6px rgba(0,210,255,0.3)' }}>INVASORES RETRÔ EM FORMAÇÃO!</h3>
              <p className="text-xs text-gray-400 mt-2 leading-relaxed">
                A galáxia está sob iminente perigo. Defenda a fronteira espacial contra hordas alienígenas coordenadas. Domine a icônica técnica do fliperama clássico!
              </p>

              {/* Tips list */}
              <div className="mt-5 space-y-3 font-mono text-[11px] border-t border-cyan-500/10 pt-4 text-gray-400">
                <div className="flex items-start gap-2.5">
                  <Star className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5 fill-current" />
                  <span>Pontos em dobro ao destruir aliens enquanto eles fazem voos rasantes!</span>
                </div>
                <div className="flex items-start gap-2.5">
                  <Star className="w-3.5 h-3.5 text-yellow-400 shrink-0 mt-0.5 fill-current" />
                  <span>Seja esperto: destrua a nave Boss no momento certo para receber a sua nave capturada de volta.</span>
                </div>
                <div className="flex items-start gap-2.5">
                  <Star className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5 fill-current" />
                  <span>A Nave Dupla expande seu hitbox, mas duplica a área de tiro e lasers!</span>
                </div>
              </div>
            </div>

            {/* Quick Controls Cheat Sheet */}
            <div className="glass-panel border-cyan-500/10 rounded-2xl p-4 font-mono text-[11.5px] space-y-1 text-gray-400 shadow-md">
              <div className="font-bold text-gray-200 uppercase text-xs mb-2 border-b border-cyan-500/10 pb-1.5 flex items-center gap-1">
                <HelpCircle className="w-4 h-4 text-cyan-400" /> Guia de Atalhos
              </div>
              <div className="flex justify-between py-1 border-b border-cyan-500/5">
                <span>Mover Esquerda</span>
                <span className="text-white bg-white/[0.04] px-1.5 py-0.5 rounded border border-white/5">Seta Esquerda ou A</span>
              </div>
              <div className="flex justify-between py-1 border-b border-cyan-500/5">
                <span>Mover Direita</span>
                <span className="text-white bg-white/[0.04] px-1.5 py-0.5 rounded border border-white/5">Seta Direita ou D</span>
              </div>
              <div className="flex justify-between py-1">
                <span>Disparar Lasers</span>
                <span className="text-white bg-white/[0.04] px-1.5 py-0.5 rounded border border-white/5">Espaço ou Seta Cima</span>
              </div>
            </div>

            {/* Live UTC indicator with pristine typographic pairing as per layout guidelines */}
            <div className="font-mono text-[9px] text-gray-600 flex justify-between px-2">
              <span>SISTEMA: ONLINE (60FPS)</span>
              <span>SESSÃO: SECURE RUNTIME</span>
            </div>

          </div>

        </div>
      </main>

      {/* 3. HUMBLE FOOTER WITH REAL VALUES */}
      <footer className="w-full bg-[#020205]/60 py-4 px-4 text-center border-t border-cyan-500/10 select-none z-10" id="retro_bottom_footer">
        <div className="max-w-4xl mx-auto flex flex-col md:flex-row justify-between items-center gap-2 text-[11px] font-mono text-gray-500">
          <span>Galaga Space Arcade © 2026. Criado por <strong className="text-cyan-400 font-bold" style={{ textShadow: '0 0 4px rgba(0,210,255,0.2)' }}>Wegah</strong>.</span>
          <div className="flex gap-4">
            <span>Desenvolvido no Brasil</span>
            <span>Versão 2.4.0 (Touch-Enabled)</span>
          </div>
        </div>
      </footer>

      {/* 4. MODAL DETALHADO DO QR CODE E DOWNLOAD */}
      {showDownloadModal && (
        <div className="fixed inset-0 bg-[#020205]/90 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in" id="download_qr_modal">
          <div className="w-full max-w-2xl bg-[#09090e] border border-cyan-500/20 rounded-2xl overflow-hidden shadow-2xl relative">
            
            {/* Header com botão de fechar */}
            <div className="flex items-center justify-between p-4 border-b border-cyan-500/10 bg-[#050508]">
              <div className="flex items-center gap-2">
                <QrCode className="w-5 h-5 text-cyan-400 animate-pulse" />
                <h3 className="text-sm font-black font-mono tracking-wider text-white uppercase" style={{ textShadow: '0 0 6px rgba(0,210,255,0.4)' }}>
                  Baixar / Jogar no Celular
                </h3>
              </div>
              <button 
                onClick={() => setShowDownloadModal(false)}
                className="p-1 rounded-full text-gray-400 hover:text-white hover:bg-white/[0.05] transition active:scale-90 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Conteúdo do modal */}
            <div className="p-6 grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
              
              {/* QR Code Column */}
              <div className="md:col-span-5 flex flex-col items-center text-center p-4 bg-white/[0.02] border border-cyan-500/5 rounded-xl">
                <div className="relative p-3.5 bg-[#020205] border-2 border-cyan-400/40 rounded-xl shadow-lg shadow-cyan-500/10">
                  {/* Decorative techno borders */}
                  <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-cyan-400 -mt-[2px] -ml-[2px]" />
                  <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-cyan-400 -mt-[2px] -mr-[2px]" />
                  <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-cyan-400 -mb-[2px] -ml-[2px]" />
                  <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-cyan-400 -mb-[2px] -mr-[2px]" />
                  
                  {/* QR Code image pointing directly to the current app URL dynamically */}
                  <img 
                    src={`https://api.qrserver.com/v1/create-qr-code/?size=160x160&color=06b6d4&bgcolor=020104&qzone=1&data=${encodeURIComponent(typeof window !== 'undefined' ? window.location.href : '')}`} 
                    alt="QR Code Galaga Arcade" 
                    className="w-40 h-40 object-contain selection:bg-transparent"
                    referrerPolicy="no-referrer"
                  />
                </div>
                
                <span className="text-[10px] text-gray-500 font-mono font-medium tracking-wider uppercase mt-3">
                  Escaneie com a câmera do celular
                </span>
              </div>

              {/* Step-by-Step Column */}
              <div className="md:col-span-7 space-y-4">
                <div className="space-y-1">
                  <span className="text-xs font-bold text-cyan-400 font-mono uppercase tracking-widest block">Instalação Offline Instantânea</span>
                  <p className="text-xs text-gray-400 leading-relaxed font-sans">
                    Transforme este site do navegador de seu celular em um aplicativo instalável real (<strong className="text-white font-medium">PWA</strong>). Ele rodará em tela inteira sem barras de navegação!
                  </p>
                </div>

                {deferredPrompt && (
                  <div className="p-3 bg-cyan-950/20 border border-cyan-400/30 rounded-xl space-y-2 text-center animate-pulse">
                    <span className="text-[9px] text-cyan-400 font-mono font-black uppercase tracking-wider block">⚡ COMPATIBILIDADE COM SEU NAVEGADOR DETECTADA!</span>
                    <button
                      onClick={triggerInstallPrompt}
                      className="w-full py-2.5 px-4 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-black font-extrabold text-xs tracking-wider uppercase transition shadow-lg shadow-cyan-500/30 active:scale-95 cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <Download className="w-4 h-4 text-black stroke-[3]" /> Instalar com 1-Clique
                    </button>
                  </div>
                )}

                <div className="space-y-2.5 font-mono text-[11px] text-gray-300">
                  <div className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-cyan-950 border border-cyan-500/30 text-cyan-400 flex items-center justify-center font-bold shrink-0 text-[10px]">1</span>
                    <span>Abra a câmera do celular, escaneie o código QR e clique no link.</span>
                  </div>

                  <div className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-cyan-950 border border-cyan-500/30 text-cyan-400 flex items-center justify-center font-bold shrink-0 text-[10px]">2</span>
                    <span>
                      No <strong className="text-cyan-300 font-bold">Android</strong>, clique nos "3 pontos" do Chrome e toque em <strong className="text-white font-semibold">"Instalar aplicativo"</strong>.
                    </span>
                  </div>

                  <div className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-cyan-950 border border-cyan-500/30 text-cyan-400 flex items-center justify-center font-bold shrink-0 text-[10px]">3</span>
                    <span>
                      No <strong className="text-cyan-300 font-bold">iPhone / iOS</strong>, use o Safari, clique no botão de <strong className="text-white font-semibold">Compartilhar [ ⇧ ]</strong> e escolha <strong className="text-white font-semibold">"Adicionar à Tela de Início"</strong>.
                    </span>
                  </div>

                  <div className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-[#16a34a]/10 border border-[#22c55e]/20 text-[#4ade80] flex items-center justify-center font-bold shrink-0 text-[10px]">✓</span>
                    <span>Um ícone será gerado e os arquivos baixados para jogar offline a qualquer momento!</span>
                  </div>
                </div>

                {/* Auxiliary links */}
                <div className="pt-2 border-t border-cyan-500/10 flex gap-2">
                  <button
                    onClick={() => {
                      // Generate a simple bootstrap offline HTML redirector download dynamically pointing to the current domain!
                      const currentUrl = typeof window !== 'undefined' ? window.location.href : '';
                      const htmlTemplate = `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Galaga Space Arcade Shortcut</title>
  <style>
    body, html { margin: 0; padding: 0; width: 100%; height: 100%; overflow: hidden; background-color: #020205; font-family: sans-serif; display: flex; flex-direction: column; justify-content: center; align-items: center; color: white; }
    iframe { width: 100%; height: 100%; border: none; }
    .loading-info { position: absolute; text-align: center; font-size: 14px; pointer-events: none; opacity: 0.6; }
  </style>
</head>
<body>
  <div class="loading-info">Iniciando Galaga Cade Arcade...</div>
  <iframe src="${currentUrl}" allow="autoplay; gamepad; vibration"></iframe>
</body>
</html>`;
                      const element = document.createElement("a");
                      const file = new Blob([htmlTemplate], {type: 'text/html'});
                      element.href = URL.createObjectURL(file);
                      element.download = "Galaga_Arcade_Launcher.html";
                      document.body.appendChild(element);
                      element.click();
                      document.body.removeChild(element);
                    }}
                    className="flex-1 py-2 px-3.5 rounded-lg border border-cyan-500/30 hover:border-cyan-500 bg-cyan-950/20 text-cyan-400 hover:text-white transition duration-150 active:scale-95 cursor-pointer font-mono text-[10px] font-bold flex items-center justify-center gap-1 uppercase"
                    title="Baixar atalho de inicialização leve para PC e Celular"
                  >
                    <Download className="w-3.5 h-3.5" /> Standalone Launcher HTML
                  </button>
                </div>

              </div>

            </div>

            {/* Footer do modal */}
            <div className="p-3.5 bg-[#050508] border-t border-cyan-500/10 flex justify-between items-center text-[10px] font-mono text-gray-500">
              <span className="flex items-center gap-1">
                <Smartphone className="w-3.5 h-3.5 text-cyan-500" /> Versão Touchscreen Ativada
              </span>
              <span>Desenvolvido por Wegah</span>
            </div>

          </div>
        </div>
      )}
    </div>
  );
}

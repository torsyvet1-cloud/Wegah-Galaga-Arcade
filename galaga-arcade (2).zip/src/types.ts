/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type GameState = 'MENU' | 'PLAYING' | 'GAMEOVER' | 'VICTORY' | 'INTRO' | 'HOW_TO_PLAY' | 'PAUSED';

export type EnemyType = 'BLUE' | 'RED' | 'YELLOW' | 'BOSS' | 'BOSS_ELITE';

export type ObstacleType = 'METEOR' | 'MINE' | 'BARRIER';

export interface Obstacle {
  id: string;
  type: ObstacleType;
  x: number;
  y: number;
  width: number;
  height: number;
  speedY: number;
  speedX: number;
  hp: number;
  maxHp: number;
  rotation: number;
  rotSpeed: number;
  scoreValue: number;
  size: number; // For rendering radius or scale
  dead?: boolean;
}

export type EnemyState = 'ENTERING' | 'GRID' | 'DIVING' | 'RETURNING' | 'TRACTOR_BEAM' | 'CAPTURING';

export interface Star {
  id: number;
  x: number;
  y: number;
  speed: number;
  size: number;
  color: string;
}

export interface Laser {
  id: string;
  x: number;
  y: number;
  dx: number;
  dy: number;
  width: number;
  height: number;
  color: string;
  fromPlayer: boolean;
  power: number;
  dead?: boolean;
}

export interface Enemy {
  id: string;
  type: EnemyType;
  state: EnemyState;
  
  // Positional and movement fields
  x: number;
  y: number;
  width: number;
  height: number;
  angle: number;
  speed: number;
  
  // Grid coordinates when in formation
  gridRow: number;
  gridCol: number;
  targetGridX: number;
  targetGridY: number;

  // Paths for entry/diving loops
  path: { x: number; y: number }[];
  pathIndex: number;

  // Battle specs
  hp: number;
  maxHp: number;
  scoreValue: number;
  
  // Timing parameters
  shootTimer: number;
  diveTimer: number;
  animFrame: number;
  sinOffset: number; // Sinuous wiggle in flights

  // Tractor beam abilities for BOSS enemy
  tractorBeamActive?: boolean;
  tractorBeamAlpha?: number;
  tractorBeamHeight?: number;
  dead?: boolean;
}

export interface Particle {
  id: string;
  x: number;
  y: number;
  dx: number;
  dy: number;
  size: number;
  color: string;
  alpha: number;
  life: number;
  maxLife: number;
  shape?: 'circle' | 'square' | 'ring' | 'triangle' | 'spoke' | 'glow-dot';
  dead?: boolean;
}

export interface FloatingText {
  id: string;
  x: number;
  y: number;
  text: string;
  color: string;
  alpha: number;
  life: number;
  dead?: boolean;
}

export interface HighScore {
  name: string;
  score: number;
  date: string;
}

package com.galaga.arcade;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
